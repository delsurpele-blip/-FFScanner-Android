#!/usr/bin/env bash
set -euo pipefail

echo "=== Compilando FF Scanner APK (Android 8 - 16) ==="
if command -v gradle >/dev/null 2>&1; then
  gradle assembleDebug assembleRelease --no-daemon
elif [ -x "./gradlew" ]; then
  ./gradlew assembleDebug assembleRelease --no-daemon
else
  echo "Error: No se encontró 'gradle' ni './gradlew'. Abre la carpeta en Android Studio."
  exit 1
fi

echo ""
echo "APKs generados correctamente:"
echo "  - Debug:   app/build/outputs/apk/debug/app-debug.apk"
echo "  - Release: app/build/outputs/apk/release/app-release.apk"
