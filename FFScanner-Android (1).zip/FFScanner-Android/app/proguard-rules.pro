# Reglas ProGuard / R8 para FF Scanner (Modo Release)
-keepattributes SourceFile,LineNumberTable,Signature,InnerClasses,EnclosingMethod
-renamesourcefileattribute SourceFile

# Mantener intacta la lógica de detección local y firmas de seguridad (SecurityLogic.kt)
-keep class com.ffscanner.app.utils.SecurityLogic { *; }
-keep class com.ffscanner.app.utils.** { *; }

# Mantener el motor de escaneo local del dispositivo (DeviceScanner.kt)
-keep class com.ffscanner.app.scanner.DeviceScanner { *; }
-keep class com.ffscanner.app.scanner.** { *; }

# Mantener los modelos de resultados, progreso, hallazgos y enumeraciones
-keep class com.ffscanner.app.model.** { *; }
-keepclassmembers enum com.ffscanner.app.model.** {
    public static **[] values();
    public static ** valueOf(java.lang.String);
}

# Mantener utilidades de reporte, sonido inicial y FileProvider en release
-keep class com.ffscanner.app.util.** { *; }
-keep class androidx.core.content.FileProvider { *; }

# Mantener soporte de Kotlin Coroutines y Reflection Metadata usado por Compose/State
-keepnames class kotlinx.coroutines.internal.MainDispatcherFactory {}
-keepnames class kotlinx.coroutines.CoroutineExceptionHandler {}
-dontwarn kotlinx.coroutines.**
