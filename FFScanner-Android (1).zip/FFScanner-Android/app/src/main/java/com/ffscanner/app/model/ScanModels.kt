package com.ffscanner.app.model

import androidx.annotation.StringRes
import com.ffscanner.app.R

enum class AppScreen {
    SPLASH,
    CONSENT,
    PERMISSIONS,
    HOME,
    SCANNING,
    RESULTS,
    ADVANCED_LOGS
}

enum class FindingSeverity {
    OK,
    REVIEW,
    ALERT
}

enum class FindingCategory(@StringRes val labelRes: Int) {
    FREE_FIRE(R.string.category_free_fire),
    SUSPICIOUS_APP(R.string.category_suspicious_app),
    SUSPICIOUS_FILE(R.string.category_suspicious_file)
}

enum class OverallStatus(@StringRes val titleRes: Int) {
    CLEAN(R.string.status_clean),
    REVIEW_ALERTS(R.string.status_review),
    INCOMPLETE(R.string.status_incomplete)
}

enum class ScanStage(@StringRes val titleRes: Int) {
    FREE_FIRE(R.string.stage_free_fire),
    APPS(R.string.stage_apps),
    FILES(R.string.stage_files)
}

data class FreeFireStatus(
    val packageName: String,
    val displayName: String,
    val installed: Boolean,
    val installerPackage: String?,
    val installerName: String,
    val isOfficialStore: Boolean
)

data class ScanFinding(
    val id: String,
    val title: String,
    val subtitle: String,
    val reason: String,
    val category: FindingCategory,
    val severity: FindingSeverity,
    val packageName: String? = null,
    val filePath: String? = null
)

data class PermissionState(
    val hasPackageQueryAccess: Boolean,
    val hasAllFilesAccess: Boolean,
    val hasInternetAndWifiAccess: Boolean,
    val networkStatusLabel: String,
    val androidVersionLabel: String
)

data class ScanProgress(
    val percentage: Int,
    val currentStage: ScanStage,
    val completedStages: Set<ScanStage>,
    val statusDetail: String,
    val isLoading: Boolean = true,
    val appsChecked: Int = 0,
    val filesChecked: Int = 0,
    val alertsFound: Int = 0,
    val liveFindings: List<ScanFinding> = emptyList(),
    val currentTargetName: String? = null
)

data class ScannedPackageLog(
    val appLabel: String,
    val packageName: String,
    val flagged: Boolean,
    val matchReason: String? = null
)

data class ScannedFileLog(
    val fileName: String,
    val relativePath: String,
    val sizeBytes: Long,
    val flagged: Boolean,
    val matchReason: String? = null
)

data class ScanResult(
    val timestampMillis: Long,
    val overallStatus: OverallStatus,
    val findings: List<ScanFinding>,
    val freeFireStatuses: List<FreeFireStatus>,
    val totalAppsChecked: Int,
    val totalFilesChecked: Int,
    val couldInspectAllApps: Boolean,
    val couldScanFiles: Boolean,
    val incompleteReasons: List<String>,
    val scannedPackages: List<ScannedPackageLog> = emptyList(),
    val scannedFiles: List<ScannedFileLog> = emptyList()
) {
    val alertCount: Int
        get() = findings.count { it.severity != FindingSeverity.OK }
}
