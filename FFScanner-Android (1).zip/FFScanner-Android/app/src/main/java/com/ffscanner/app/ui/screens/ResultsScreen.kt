package com.ffscanner.app.ui.screens

import android.content.pm.PackageManager
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.AnimatedVisibilityScope
import androidx.compose.animation.BoundsTransform
import androidx.compose.animation.ExperimentalSharedTransitionApi
import androidx.compose.animation.SharedTransitionScope
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.scaleIn
import androidx.compose.animation.slideInVertically
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Apps
import androidx.compose.material.icons.outlined.CheckCircle
import androidx.compose.material.icons.outlined.Description
import androidx.compose.material.icons.outlined.ErrorOutline
import androidx.compose.material.icons.outlined.OpenInNew
import androidx.compose.material.icons.outlined.SportsEsports
import androidx.compose.material.icons.outlined.WarningAmber
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.graphics.drawscope.scale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.ffscanner.app.R
import com.ffscanner.app.model.FindingCategory
import com.ffscanner.app.model.FindingSeverity
import com.ffscanner.app.model.OverallStatus
import com.ffscanner.app.model.ScanFinding
import com.ffscanner.app.model.ScanResult
import com.ffscanner.app.ui.components.AppPackageIcon
import com.ffscanner.app.ui.components.FixedDisclaimerBanner
import com.ffscanner.app.ui.components.PressablePrimaryButton
import com.ffscanner.app.ui.components.PressableSecondaryButton
import com.ffscanner.app.ui.components.triggerShortHaptic
import com.ffscanner.app.ui.theme.LocalFFColors
import com.ffscanner.app.util.ShareHelper
import kotlinx.coroutines.delay
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

@OptIn(ExperimentalSharedTransitionApi::class)
@Composable
fun ResultsScreen(
    result: ScanResult,
    onRescan: () -> Unit,
    sharedTransitionScope: SharedTransitionScope,
    animatedVisibilityScope: AnimatedVisibilityScope
) {
    val context = LocalContext.current
    val view = LocalView.current
    val haptic = LocalHapticFeedback.current
    val packageManager = remember(context) { context.packageManager }
    val colors = LocalFFColors.current
    var showShareDialog by remember { mutableStateOf(false) }
    val sharedBoundsTransform = remember {
        BoundsTransform { _, _ ->
            spring(
                dampingRatio = 0.82f,
                stiffness = Spring.StiffnessMediumLow
            )
        }
    }

    val animatedAlertCount = remember(result.timestampMillis) { Animatable(0f) }
    LaunchedEffect(result.timestampMillis) {
        animatedAlertCount.animateTo(
            targetValue = result.alertCount.toFloat(),
            animationSpec = tween(durationMillis = 700, easing = FastOutSlowInEasing)
        )
    }

    val headerColor = when {
        result.overallStatus == OverallStatus.INCOMPLETE -> colors.statusAmber
        result.alertCount == 0 -> colors.statusGreen
        result.findings.any { it.severity == FindingSeverity.ALERT } -> colors.statusRed
        else -> colors.statusAmber
    }

    val headerIcon = when {
        result.overallStatus == OverallStatus.INCOMPLETE -> Icons.Outlined.WarningAmber
        result.alertCount == 0 -> Icons.Outlined.CheckCircle
        result.findings.any { it.severity == FindingSeverity.ALERT } -> Icons.Outlined.ErrorOutline
        else -> Icons.Outlined.WarningAmber
    }

    val headerHeadline = when (result.overallStatus) {
        OverallStatus.CLEAN -> stringResource(R.string.status_clean)
        OverallStatus.REVIEW_ALERTS -> stringResource(
            R.string.status_review_count,
            animatedAlertCount.value.toInt()
        )
        OverallStatus.INCOMPLETE -> stringResource(R.string.status_incomplete)
    }

    with(sharedTransitionScope) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(colors.background)
            .statusBarsPadding()
            .navigationBarsPadding()
            .padding(horizontal = 18.dp, vertical = 14.dp)
    ) {
        LazyColumn(
            modifier = Modifier.weight(1f),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            contentPadding = PaddingValues(bottom = 14.dp)
        ) {
            // Tarjeta principal de estado conectada con las métricas del escaneo
            item {
                Surface(
                    modifier = Modifier
                        .fillMaxWidth()
                        .sharedBounds(
                            sharedContentState = rememberSharedContentState(key = "scan_summary_card"),
                            animatedVisibilityScope = animatedVisibilityScope,
                            boundsTransform = sharedBoundsTransform,
                            resizeMode = SharedTransitionScope.ResizeMode.RemeasureToBounds
                        ),
                    color = colors.surface,
                    shape = RoundedCornerShape(18.dp),
                    border = BorderStroke(1.5.dp, headerColor.copy(alpha = 0.8f))
                ) {
                    Column(
                        modifier = Modifier.padding(18.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(50.dp)
                                    .sharedElement(
                                        state = rememberSharedContentState(key = "scan_hero_emblem"),
                                        animatedVisibilityScope = animatedVisibilityScope,
                                        boundsTransform = sharedBoundsTransform,
                                        zIndexInOverlay = 1f
                                    )
                                    .background(headerColor.copy(alpha = 0.14f), CircleShape)
                                    .border(1.5.dp, headerColor.copy(alpha = 0.7f), CircleShape),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = headerIcon,
                                    contentDescription = null,
                                    tint = headerColor,
                                    modifier = Modifier.size(28.dp)
                                )
                            }
                            Column {
                                Text(
                                    text = headerHeadline,
                                    style = MaterialTheme.typography.headlineMedium.copy(
                                        fontWeight = FontWeight.Bold
                                    ),
                                    color = headerColor,
                                    modifier = Modifier.sharedBounds(
                                        sharedContentState = rememberSharedContentState(key = "scan_headline"),
                                        animatedVisibilityScope = animatedVisibilityScope,
                                        boundsTransform = sharedBoundsTransform,
                                        resizeMode = SharedTransitionScope.ResizeMode.RemeasureToBounds,
                                        zIndexInOverlay = 1f
                                    )
                                )
                                Text(
                                    text = stringResource(
                                        R.string.results_summary_counts,
                                        result.totalAppsChecked,
                                        result.totalFilesChecked
                                    ),
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = colors.textSecondary
                                )
                            }
                        }

                        if (result.incompleteReasons.isNotEmpty()) {
                            result.incompleteReasons.forEach { reason ->
                                Text(
                                    text = "• $reason",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = colors.statusAmber
                                )
                            }
                        }
                    }
                }
            }

            // Estado de Free Fire y Free Fire MAX conectado con la etapa inicial
            item {
                Surface(
                    modifier = Modifier
                        .fillMaxWidth()
                        .sharedBounds(
                            sharedContentState = rememberSharedContentState(key = "free_fire_card"),
                            animatedVisibilityScope = animatedVisibilityScope,
                            boundsTransform = sharedBoundsTransform,
                            resizeMode = SharedTransitionScope.ResizeMode.RemeasureToBounds
                        ),
                    color = colors.surface,
                    shape = RoundedCornerShape(16.dp),
                    border = BorderStroke(colors.borderWidth, colors.border)
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Outlined.SportsEsports,
                                contentDescription = null,
                                tint = colors.accent,
                                modifier = Modifier.size(20.dp)
                            )
                            Text(
                                text = stringResource(R.string.results_ff_section_title),
                                style = MaterialTheme.typography.titleMedium,
                                color = colors.textPrimary
                            )
                        }

                        result.freeFireStatuses.forEach { ff ->
                            val statusColor = when {
                                !ff.installed -> colors.textSecondary
                                ff.isOfficialStore -> colors.statusGreen
                                else -> colors.statusRed
                            }
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                AppPackageIcon(
                                    packageName = if (ff.installed) ff.packageName else null,
                                    fallbackIcon = Icons.Outlined.SportsEsports,
                                    fallbackTint = statusColor,
                                    size = 38.dp,
                                    packageManager = packageManager
                                )
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = ff.displayName,
                                        style = MaterialTheme.typography.labelLarge,
                                        color = colors.textPrimary,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    Text(
                                        text = ff.packageName,
                                        style = MaterialTheme.typography.bodyMedium.copy(
                                            fontFamily = FontFamily.Monospace,
                                            fontSize = 11.sp
                                        ),
                                        color = colors.textSecondary,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    Text(
                                        text = ff.installerName,
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = statusColor
                                    )
                                }
                                if (ff.installed) {
                                    TextButton(
                                        onClick = {
                                            ShareHelper.openAppDetailsSettings(context, ff.packageName)
                                        }
                                    ) {
                                        Text(
                                            text = stringResource(R.string.results_ff_settings),
                                            color = colors.accent
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // Lista de hallazgos con entrada escalonada desde abajo
            if (result.findings.isEmpty()) {
                item {
                    val isCleanVerdict = result.overallStatus == OverallStatus.CLEAN
                    val cleanCardBorder = if (isCleanVerdict) {
                        Color(0xFFF59E0B).copy(alpha = 0.72f)
                    } else {
                        colors.statusAmber.copy(alpha = 0.6f)
                    }
                    Surface(
                        modifier = Modifier.fillMaxWidth(),
                        color = colors.surface,
                        shape = RoundedCornerShape(16.dp),
                        border = BorderStroke(colors.borderWidth, cleanCardBorder)
                    ) {
                        Column(
                            modifier = Modifier.padding(18.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            if (isCleanVerdict) {
                                CleanGoldenShieldCelebration(
                                    scanTimestamp = result.timestampMillis,
                                    isHighContrast = colors.isHighContrast,
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(156.dp)
                                )
                            }
                            Text(
                                text = stringResource(R.string.results_no_findings_title),
                                style = MaterialTheme.typography.titleMedium,
                                color = if (isCleanVerdict) colors.statusGreen else colors.statusAmber
                            )
                            Text(
                                text = stringResource(R.string.results_no_findings_desc),
                                style = MaterialTheme.typography.bodyMedium,
                                color = colors.textSecondary
                            )
                        }
                    }
                }
            } else {
                item {
                    Text(
                        text = stringResource(R.string.results_findings_header, result.findings.size),
                        style = MaterialTheme.typography.titleMedium,
                        color = colors.textPrimary,
                        modifier = Modifier.padding(top = 4.dp)
                    )
                }

                itemsIndexed(
                    items = result.findings,
                    key = { _, item -> item.id }
                ) { index, finding ->
                    StaggeredFindingCard(
                        finding = finding,
                        index = index,
                        scanTimestamp = result.timestampMillis,
                        packageManager = packageManager,
                        onOpenAppSettings = { pkg ->
                            ShareHelper.openAppDetailsSettings(context, pkg)
                        }
                    )
                }
            }
        }

        // Botones inferiores y aviso fijo
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                PressablePrimaryButton(
                    text = stringResource(R.string.results_rescan_button),
                    onClick = {
                        triggerShortHaptic(view, haptic, isStageCompletion = false)
                        onRescan()
                    },
                    modifier = Modifier.weight(1f)
                )
                PressableSecondaryButton(
                    text = stringResource(R.string.results_share_button),
                    onClick = { showShareDialog = true },
                    modifier = Modifier.weight(1f)
                )
            }

            FixedDisclaimerBanner()
        }
    }
    }

    if (showShareDialog) {
        AlertDialog(
            onDismissRequest = { showShareDialog = false },
            containerColor = colors.surfaceElevated,
            titleContentColor = colors.textPrimary,
            textContentColor = colors.textSecondary,
            title = { Text(stringResource(R.string.results_share_dialog_title)) },
            text = {
                Text(stringResource(R.string.results_share_dialog_body))
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        showShareDialog = false
                        ShareHelper.shareAsScreenshot(context, result)
                    }
                ) {
                    Text(stringResource(R.string.results_share_screenshot), color = colors.accent)
                }
            },
            dismissButton = {
                TextButton(
                    onClick = {
                        showShareDialog = false
                        ShareHelper.shareAsText(context, result)
                    }
                ) {
                    Text(stringResource(R.string.results_share_text), color = colors.textPrimary)
                }
            }
        )
    }
}

@Composable
private fun StaggeredFindingCard(
    finding: ScanFinding,
    index: Int,
    scanTimestamp: Long,
    packageManager: PackageManager,
    onOpenAppSettings: (String) -> Unit
) {
    val colors = LocalFFColors.current
    var visible by remember(scanTimestamp, finding.id) { mutableStateOf(false) }
    LaunchedEffect(scanTimestamp, finding.id) {
        delay((index.coerceAtMost(10) * 90).toLong())
        visible = true
    }

    val severityColor = when (finding.severity) {
        FindingSeverity.OK -> colors.statusGreen
        FindingSeverity.REVIEW -> colors.statusAmber
        FindingSeverity.ALERT -> colors.statusRed
    }
    val severityLabel = when (finding.severity) {
        FindingSeverity.OK -> stringResource(R.string.severity_ok)
        FindingSeverity.REVIEW -> stringResource(R.string.severity_review)
        FindingSeverity.ALERT -> stringResource(R.string.severity_alert)
    }

    AnimatedVisibility(
        visible = visible,
        enter = fadeIn(animationSpec = tween(durationMillis = 260)) +
            slideInVertically(
                animationSpec = spring(
                    dampingRatio = 0.68f,
                    stiffness = Spring.StiffnessMediumLow
                ),
                initialOffsetY = { (it * 0.4f).toInt().coerceAtLeast(72) }
            ) +
            scaleIn(
                initialScale = 0.92f,
                animationSpec = spring(
                    dampingRatio = 0.68f,
                    stiffness = Spring.StiffnessMediumLow
                )
            )
    ) {
        Surface(
            modifier = Modifier.fillMaxWidth(),
            color = colors.surface,
            shape = RoundedCornerShape(16.dp),
            border = BorderStroke(colors.borderWidth, severityColor.copy(alpha = 0.7f))
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = stringResource(finding.category.labelRes),
                        style = MaterialTheme.typography.bodyMedium.copy(fontSize = 12.sp),
                        color = colors.accent
                    )
                    Text(
                        text = severityLabel,
                        style = MaterialTheme.typography.labelLarge.copy(fontSize = 12.sp),
                        color = severityColor
                    )
                }

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    AppPackageIcon(
                        packageName = finding.packageName,
                        fallbackIcon = if (finding.category == FindingCategory.SUSPICIOUS_FILE) {
                            Icons.Outlined.Description
                        } else {
                            Icons.Outlined.Apps
                        },
                        fallbackTint = severityColor,
                        size = 42.dp,
                        apkFilePath = finding.filePath,
                        packageManager = packageManager
                    )
                    Column(
                        modifier = Modifier.weight(1f),
                        verticalArrangement = Arrangement.spacedBy(2.dp)
                    ) {
                        Text(
                            text = finding.title,
                            style = MaterialTheme.typography.titleMedium,
                            color = colors.textPrimary,
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            text = finding.packageName ?: finding.subtitle,
                            style = MaterialTheme.typography.bodyMedium.copy(
                                fontFamily = FontFamily.Monospace,
                                fontSize = 12.sp
                            ),
                            color = colors.textSecondary,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        if (finding.packageName != null && finding.subtitle != finding.packageName) {
                            Text(
                                text = finding.subtitle,
                                style = MaterialTheme.typography.bodyMedium.copy(fontSize = 12.sp),
                                color = colors.textSecondary,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }
                }

                Text(
                    text = stringResource(R.string.results_reason_format, finding.reason),
                    style = MaterialTheme.typography.bodyMedium,
                    color = colors.textPrimary
                )

                if (finding.packageName != null) {
                    Box(modifier = Modifier.padding(top = 4.dp)) {
                        OutlinedButton(
                            onClick = { onOpenAppSettings(finding.packageName) },
                            shape = RoundedCornerShape(10.dp),
                            border = BorderStroke(colors.borderWidth, colors.border)
                        ) {
                            Icon(
                                imageVector = Icons.Outlined.OpenInNew,
                                contentDescription = null,
                                tint = colors.accent,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.size(8.dp))
                            Text(
                                text = stringResource(R.string.results_open_app_settings),
                                color = colors.textPrimary,
                                style = MaterialTheme.typography.labelLarge
                            )
                        }
                    }
                }
            }
        }
    }
}

private data class GoldSparkleParticle(
    val angleRad: Float,
    val baseOrbitFactor: Float,
    val driftSpeed: Float,
    val orbitSpeed: Float,
    val sizeDp: Float,
    val phaseOffset: Float,
    val isFourPointStar: Boolean
)

@Composable
private fun CleanGoldenShieldCelebration(
    scanTimestamp: Long,
    isHighContrast: Boolean,
    modifier: Modifier = Modifier
) {
    val entranceScale = remember(scanTimestamp) { Animatable(0.42f) }
    val checkDrawProgress = remember(scanTimestamp) { Animatable(0f) }
    var elapsedSeconds by remember(scanTimestamp) { mutableFloatStateOf(0f) }

    val particles = remember {
        List(24) { idx ->
            val fraction = idx / 24f
            GoldSparkleParticle(
                angleRad = (fraction * 2f * PI.toFloat()) + (idx % 3) * 0.21f,
                baseOrbitFactor = 0.56f + ((idx * 17) % 10) * 0.048f,
                driftSpeed = 0.24f + (idx % 5) * 0.08f,
                orbitSpeed = if (idx % 2 == 0) 0.34f else -0.26f,
                sizeDp = 1.9f + (idx % 4) * 0.85f,
                phaseOffset = idx * 0.73f,
                isFourPointStar = idx % 3 == 0
            )
        }
    }

    LaunchedEffect(scanTimestamp) {
        entranceScale.animateTo(
            targetValue = 1f,
            animationSpec = spring(
                dampingRatio = 0.58f,
                stiffness = Spring.StiffnessMediumLow
            )
        )
    }

    LaunchedEffect(scanTimestamp) {
        delay(160)
        checkDrawProgress.animateTo(
            targetValue = 1f,
            animationSpec = tween(durationMillis = 520, easing = FastOutSlowInEasing)
        )
    }

    LaunchedEffect(scanTimestamp) {
        var lastFrameNanos = withFrameNanos { it }
        while (true) {
            withFrameNanos { frameNanos ->
                val dt = ((frameNanos - lastFrameNanos).coerceAtLeast(0L)) / 1_000_000_000f
                lastFrameNanos = frameNanos
                elapsedSeconds += dt.coerceAtMost(0.05f)
            }
        }
    }

    val goldBright = Color(0xFFFFFBEB)
    val goldLight = Color(0xFFFDE68A)
    val goldMid = Color(0xFFF59E0B)
    val goldDeep = Color(0xFFB45309)
    val goldRim = if (isHighContrast) Color(0xFF92400E) else Color(0xFFFEF3C7)

    Canvas(modifier = modifier) {
        val w = size.width
        val h = size.height
        val cx = w / 2f
        val cy = h / 2f
        val shieldRadius = minOf(w, h) * 0.34f
        val breathe = 0.5f + 0.5f * sin(elapsedSeconds * 2.2f)

        // Aura radial dorada pulsante
        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(
                    goldMid.copy(alpha = if (isHighContrast) 0.20f else (0.28f + 0.12f * breathe)),
                    goldLight.copy(alpha = if (isHighContrast) 0.10f else 0.14f),
                    Color.Transparent
                ),
                center = Offset(cx, cy),
                radius = shieldRadius * 2.15f
            ),
            radius = shieldRadius * 2.15f,
            center = Offset(cx, cy)
        )

        // Anillos expansivos suaves de seguridad reforzada
        for (ringIdx in 0 until 2) {
            val ringPhase = (elapsedSeconds * 0.48f + ringIdx * 0.5f) % 1f
            val ringRadius = shieldRadius * (0.95f + 1.05f * ringPhase)
            val ringAlpha = (1f - ringPhase) * (1f - ringPhase) * (if (isHighContrast) 0.38f else 0.45f)
            drawCircle(
                color = goldMid.copy(alpha = ringAlpha),
                radius = ringRadius,
                center = Offset(cx, cy),
                style = Stroke(width = 1.8.dp.toPx())
            )
        }

        // Partículas doradas brillantes orbitando y ascendiendo
        particles.forEach { p ->
            val twinkle = (0.5f + 0.5f * sin(elapsedSeconds * 3.6f + p.phaseOffset)).coerceIn(0f, 1f)
            val currentAngle = p.angleRad + elapsedSeconds * p.orbitSpeed
            val radialPulse = shieldRadius * (p.baseOrbitFactor + 0.55f * ((elapsedSeconds * p.driftSpeed + p.phaseOffset) % 1f))
            val floatUp = -sin(((elapsedSeconds * p.driftSpeed + p.phaseOffset) % 1f) * PI.toFloat()) * 8.dp.toPx()

            val px = cx + cos(currentAngle) * radialPulse * 1.18f
            val py = cy + sin(currentAngle) * radialPulse * 0.86f + floatUp
            val particleAlpha = (0.28f + 0.72f * twinkle) * entranceScale.value.coerceIn(0f, 1f)
            val pRadius = p.sizeDp.dp.toPx() * (0.75f + 0.45f * twinkle)

            // Halo del destello
            drawCircle(
                color = goldMid.copy(alpha = particleAlpha * 0.35f),
                radius = pRadius * 2.3f,
                center = Offset(px, py)
            )

            if (p.isFourPointStar) {
                val starArm = pRadius * 2.1f
                val innerArm = pRadius * 0.55f
                val starPath = Path().apply {
                    moveTo(px, py - starArm)
                    lineTo(px + innerArm, py - innerArm)
                    lineTo(px + starArm, py)
                    lineTo(px + innerArm, py + innerArm)
                    lineTo(px, py + starArm)
                    lineTo(px - innerArm, py + innerArm)
                    lineTo(px - starArm, py)
                    lineTo(px - innerArm, py - innerArm)
                    close()
                }
                drawPath(path = starPath, color = goldBright.copy(alpha = particleAlpha))
            } else {
                drawCircle(
                    color = goldLight.copy(alpha = particleAlpha),
                    radius = pRadius,
                    center = Offset(px, py)
                )
            }
        }

        // Escudo dorado heráldico con brillo metálico y destello diagonal
        val shieldWidth = shieldRadius * 1.62f
        val shieldHeight = shieldRadius * 1.92f
        val topY = cy - shieldHeight * 0.50f
        val bottomY = cy + shieldHeight * 0.50f
        val leftX = cx - shieldWidth * 0.50f
        val rightX = cx + shieldWidth * 0.50f

        val shieldPath = Path().apply {
            moveTo(cx, topY)
            lineTo(rightX, topY + shieldHeight * 0.16f)
            lineTo(rightX, topY + shieldHeight * 0.48f)
            cubicTo(
                rightX, topY + shieldHeight * 0.74f,
                cx + shieldWidth * 0.24f, topY + shieldHeight * 0.90f,
                cx, bottomY
            )
            cubicTo(
                cx - shieldWidth * 0.24f, topY + shieldHeight * 0.90f,
                leftX, topY + shieldHeight * 0.74f,
                leftX, topY + shieldHeight * 0.48f
            )
            lineTo(leftX, topY + shieldHeight * 0.16f)
            close()
        }

        val scaleFactor = entranceScale.value
        scale(scale = scaleFactor, pivot = Offset(cx, cy)) {
            drawPath(
                path = shieldPath,
                brush = Brush.linearGradient(
                    colors = listOf(goldBright, goldLight, goldMid, goldDeep),
                    start = Offset(leftX, topY),
                    end = Offset(rightX, bottomY)
                )
            )

            // Brillo diagonal que recorre el escudo dorado periódicamente
            val shimmerCycle = (elapsedSeconds * 0.55f) % 2.4f
            if (shimmerCycle <= 1.1f) {
                val sweepProgress = shimmerCycle / 1.1f
                val sweepStartX = leftX - shieldWidth * 0.4f + shieldWidth * 1.8f * sweepProgress
                clipPath(shieldPath) {
                    drawLine(
                        brush = Brush.linearGradient(
                            colors = listOf(
                                Color.Transparent,
                                goldBright.copy(alpha = 0.58f),
                                Color.Transparent
                            ),
                            start = Offset(sweepStartX - 18.dp.toPx(), topY),
                            end = Offset(sweepStartX + 18.dp.toPx(), bottomY)
                        ),
                        start = Offset(sweepStartX - 18.dp.toPx(), topY - 12.dp.toPx()),
                        end = Offset(sweepStartX + 18.dp.toPx(), bottomY + 12.dp.toPx()),
                        strokeWidth = 22.dp.toPx()
                    )
                }
            }

            // Contorno metálico del escudo
            drawPath(
                path = shieldPath,
                color = goldRim,
                style = Stroke(width = 2.4.dp.toPx(), join = StrokeJoin.Round)
            )

            // Checkmark central animado sobre el escudo dorado
            val checkP = checkDrawProgress.value
            if (checkP > 0f) {
                val p1 = Offset(cx - shieldWidth * 0.21f, cy + shieldHeight * 0.02f)
                val p2 = Offset(cx - shieldWidth * 0.04f, cy + shieldHeight * 0.18f)
                val p3 = Offset(cx + shieldWidth * 0.24f, cy - shieldHeight * 0.14f)
                val checkPath = Path().apply {
                    moveTo(p1.x, p1.y)
                    val first = (checkP * 2f).coerceIn(0f, 1f)
                    lineTo(p1.x + (p2.x - p1.x) * first, p1.y + (p2.y - p1.y) * first)
                    if (checkP > 0.5f) {
                        val second = ((checkP - 0.5f) * 2f).coerceIn(0f, 1f)
                        lineTo(p2.x + (p3.x - p2.x) * second, p2.y + (p3.y - p2.y) * second)
                    }
                }
                drawPath(
                    path = checkPath,
                    color = Color(0xFF451A03),
                    style = Stroke(
                        width = 4.2.dp.toPx(),
                        cap = StrokeCap.Round,
                        join = StrokeJoin.Round
                    )
                )
            }
        }
    }
}
