package com.ffscanner.app.ui.theme

import androidx.compose.ui.graphics.Color

// Tema azul oscuro por defecto
val NavyBackground = Color(0xFF0A1128)
val NavySurface = Color(0xFF111C3D)
val NavySurfaceElevated = Color(0xFF17254F)
val NavyBorder = Color(0xFF233872)

val ElectricBlue = Color(0xFF1E6BFF)
val CyanAccent = Color(0xFF00D4FF)

val TextWhite = Color(0xFFFFFFFF)
val TextMuted = Color(0xFFB3C3E6)

val StatusGreen = Color(0xFF22C55E)
val StatusAmber = Color(0xFFF59E0B)
val StatusRed = Color(0xFFEF4444)

// Modo de alto contraste para legibilidad en exteriores (luz solar directa)
val OutdoorBackground = Color(0xFFFFFFFF)
val OutdoorSurface = Color(0xFFF1F5F9)
val OutdoorSurfaceElevated = Color(0xFFE2E8F0)
val OutdoorBorder = Color(0xFF0F172A)

val OutdoorBlue = Color(0xFF0038A8)
val OutdoorCyan = Color(0xFF0369A1)

val OutdoorTextPrimary = Color(0xFF050A18)
val OutdoorTextSecondary = Color(0xFF1E293B)

val OutdoorGreen = Color(0xFF15803D)
val OutdoorAmber = Color(0xFFB45309)
val OutdoorRed = Color(0xFFB91C1C)
