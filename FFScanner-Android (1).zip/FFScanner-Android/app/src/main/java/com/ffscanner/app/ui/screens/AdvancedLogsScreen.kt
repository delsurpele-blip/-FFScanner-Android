package com.ffscanner.app.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.ArrowBack
import androidx.compose.material.icons.outlined.Apps
import androidx.compose.material.icons.outlined.ContentCopy
import androidx.compose.material.icons.outlined.Description
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material.icons.outlined.Terminal
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.ffscanner.app.R
import com.ffscanner.app.model.ScanResult
import com.ffscanner.app.model.ScannedFileLog
import com.ffscanner.app.model.ScannedPackageLog
import com.ffscanner.app.ui.components.AppPackageIcon
import com.ffscanner.app.ui.theme.LocalFFColors
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private enum class LogFilterTab {
    ALL,
    PACKAGES,
    FILES
}

@Composable
fun AdvancedLogsScreen(
    lastResult: ScanResult?,
    onBack: () -> Unit
) {
    val colors = LocalFFColors.current
    val clipboard = LocalClipboardManager.current
    var searchQuery by remember { mutableStateOf("") }
    var activeTab by remember { mutableStateOf(LogFilterTab.ALL) }
    var copiedBanner by remember { mutableStateOf(false) }

    LaunchedEffect(copiedBanner) {
        if (copiedBanner) {
            delay(2000)
            copiedBanner = false
        }
    }

    val packages = lastResult?.scannedPackages.orEmpty()
    val files = lastResult?.scannedFiles.orEmpty()
    val query = searchQuery.trim().lowercase(Locale.getDefault())

    val filteredPackages = remember(packages, query) {
        if (query.isEmpty()) packages
        else packages.filter {
            it.packageName.lowercase(Locale.getDefault()).contains(query) ||
                it.appLabel.lowercase(Locale.getDefault()).contains(query)
        }
    }
    val filteredFiles = remember(files, query) {
        if (query.isEmpty()) files
        else files.filter {
            it.relativePath.lowercase(Locale.getDefault()).contains(query) ||
                it.fileName.lowercase(Locale.getDefault()).contains(query)
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(colors.background)
            .statusBarsPadding()
            .navigationBarsPadding()
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Cabecera superior
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.weight(1f)
            ) {
                IconButton(onClick = onBack) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Outlined.ArrowBack,
                        contentDescription = stringResource(R.string.logs_back_cd),
                        tint = colors.textPrimary
                    )
                }
                Column {
                    Text(
                        text = stringResource(R.string.logs_title),
                        style = MaterialTheme.typography.titleLarge,
                        color = colors.textPrimary,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    if (lastResult != null) {
                        val dateStr = remember(lastResult.timestampMillis) {
                            SimpleDateFormat("dd/MM/yyyy HH:mm:ss", Locale.getDefault())
                                .format(Date(lastResult.timestampMillis))
                        }
                        Text(
                            text = stringResource(R.string.logs_last_run, dateStr),
                            style = MaterialTheme.typography.bodyMedium.copy(fontSize = 12.sp),
                            color = colors.accent
                        )
                    }
                }
            }

            if (lastResult != null) {
                TextButton(
                    onClick = {
                        val rawText = buildRawLogsText(lastResult)
                        clipboard.setText(AnnotatedString(rawText))
                        copiedBanner = true
                    }
                ) {
                    Icon(
                        imageVector = Icons.Outlined.ContentCopy,
                        contentDescription = null,
                        tint = colors.accent,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.size(6.dp))
                    Text(
                        text = stringResource(R.string.logs_copy_button),
                        color = colors.accent,
                        style = MaterialTheme.typography.labelLarge
                    )
                }
            }
        }

        if (copiedBanner) {
            Surface(
                modifier = Modifier.fillMaxWidth(),
                color = colors.statusGreen.copy(alpha = 0.16f),
                shape = RoundedCornerShape(10.dp),
                border = BorderStroke(1.dp, colors.statusGreen)
            ) {
                Text(
                    text = stringResource(R.string.logs_copied_message),
                    style = MaterialTheme.typography.bodyMedium,
                    color = colors.statusGreen,
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)
                )
            }
        }

        if (lastResult == null) {
            Box(
                modifier = Modifier.fillMaxSize(),
                contentAlignment = Alignment.Center
            ) {
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    color = colors.surface,
                    shape = RoundedCornerShape(16.dp),
                    border = BorderStroke(colors.borderWidth, colors.border)
                ) {
                    Column(
                        modifier = Modifier.padding(20.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Outlined.Terminal,
                            contentDescription = null,
                            tint = colors.accent,
                            modifier = Modifier.size(32.dp)
                        )
                        Text(
                            text = stringResource(R.string.logs_no_scan_yet),
                            style = MaterialTheme.typography.bodyMedium,
                            color = colors.textSecondary
                        )
                    }
                }
            }
            return@Column
        }

        OutlinedTextField(
            value = searchQuery,
            onValueChange = { searchQuery = it },
            singleLine = true,
            leadingIcon = {
                Icon(
                    imageVector = Icons.Outlined.Search,
                    contentDescription = null,
                    tint = colors.accent
                )
            },
            placeholder = {
                Text(
                    text = stringResource(R.string.logs_search_placeholder),
                    style = MaterialTheme.typography.bodyMedium,
                    color = colors.textSecondary
                )
            },
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = colors.primary,
                unfocusedBorderColor = colors.border,
                focusedContainerColor = colors.surface,
                unfocusedContainerColor = colors.surface,
                focusedTextColor = colors.textPrimary,
                unfocusedTextColor = colors.textPrimary
            ),
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier.fillMaxWidth()
        )

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            FilterChip(
                selected = activeTab == LogFilterTab.ALL,
                onClick = { activeTab = LogFilterTab.ALL },
                label = {
                    Text(
                        text = stringResource(
                            R.string.logs_tab_all,
                            filteredPackages.size + filteredFiles.size
                        ),
                        fontSize = 12.sp
                    )
                },
                colors = FilterChipDefaults.filterChipColors(
                    selectedContainerColor = colors.primary,
                    selectedLabelColor = Color.White,
                    containerColor = colors.surface,
                    labelColor = colors.textSecondary
                )
            )
            FilterChip(
                selected = activeTab == LogFilterTab.PACKAGES,
                onClick = { activeTab = LogFilterTab.PACKAGES },
                label = {
                    Text(
                        text = stringResource(R.string.logs_tab_packages, filteredPackages.size),
                        fontSize = 12.sp
                    )
                },
                colors = FilterChipDefaults.filterChipColors(
                    selectedContainerColor = colors.primary,
                    selectedLabelColor = Color.White,
                    containerColor = colors.surface,
                    labelColor = colors.textSecondary
                )
            )
            FilterChip(
                selected = activeTab == LogFilterTab.FILES,
                onClick = { activeTab = LogFilterTab.FILES },
                label = {
                    Text(
                        text = stringResource(R.string.logs_tab_files, filteredFiles.size),
                        fontSize = 12.sp
                    )
                },
                colors = FilterChipDefaults.filterChipColors(
                    selectedContainerColor = colors.primary,
                    selectedLabelColor = Color.White,
                    containerColor = colors.surface,
                    labelColor = colors.textSecondary
                )
            )
        }

        if (lastResult.totalFilesChecked > files.size && files.isNotEmpty()) {
            Text(
                text = stringResource(
                    R.string.logs_truncated_note,
                    files.size,
                    lastResult.totalFilesChecked
                ),
                style = MaterialTheme.typography.bodyMedium.copy(fontSize = 12.sp),
                color = colors.textSecondary
            )
        }

        val showPackages = activeTab == LogFilterTab.ALL || activeTab == LogFilterTab.PACKAGES
        val showFiles = activeTab == LogFilterTab.ALL || activeTab == LogFilterTab.FILES
        val hasItems = (showPackages && filteredPackages.isNotEmpty()) || (showFiles && filteredFiles.isNotEmpty())

        if (!hasItems && query.isNotEmpty()) {
            Surface(
                modifier = Modifier.fillMaxWidth(),
                color = colors.surface,
                shape = RoundedCornerShape(14.dp),
                border = BorderStroke(colors.borderWidth, colors.border)
            ) {
                Text(
                    text = stringResource(R.string.logs_empty_filter, searchQuery),
                    style = MaterialTheme.typography.bodyMedium,
                    color = colors.textSecondary,
                    modifier = Modifier.padding(16.dp)
                )
            }
        } else {
            LazyColumn(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(8.dp),
                contentPadding = PaddingValues(bottom = 16.dp)
            ) {
                if (showPackages && filteredPackages.isNotEmpty()) {
                    item(key = "header_packages") {
                        Text(
                            text = stringResource(R.string.logs_section_packages),
                            style = MaterialTheme.typography.titleMedium,
                            color = colors.accent,
                            modifier = Modifier.padding(top = 4.dp, bottom = 2.dp)
                        )
                    }
                    items(
                        items = filteredPackages,
                        key = { "pkg_${it.packageName}" }
                    ) { pkg ->
                        PackageLogRow(pkg = pkg)
                    }
                }

                if (showFiles && filteredFiles.isNotEmpty()) {
                    item(key = "header_files") {
                        Text(
                            text = stringResource(R.string.logs_section_files),
                            style = MaterialTheme.typography.titleMedium,
                            color = colors.accent,
                            modifier = Modifier.padding(top = 8.dp, bottom = 2.dp)
                        )
                    }
                    items(
                        items = filteredFiles,
                        key = { "file_${it.relativePath}" }
                    ) { file ->
                        FileLogRow(file = file)
                    }
                }
            }
        }
    }
}

@Composable
private fun PackageLogRow(pkg: ScannedPackageLog) {
    val colors = LocalFFColors.current
    val badgeColor = if (pkg.flagged) colors.statusRed else colors.statusGreen
    Surface(
        modifier = Modifier.fillMaxWidth(),
        color = colors.surface,
        shape = RoundedCornerShape(12.dp),
        border = BorderStroke(
            width = colors.borderWidth,
            color = if (pkg.flagged) colors.statusRed.copy(alpha = 0.7f) else colors.border
        )
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            AppPackageIcon(
                packageName = pkg.packageName,
                fallbackIcon = Icons.Outlined.Apps,
                fallbackTint = badgeColor,
                size = 34.dp
            )
            Column(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(3.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        text = pkg.appLabel,
                        style = MaterialTheme.typography.labelLarge.copy(fontSize = 13.sp),
                        color = colors.textPrimary,
                        modifier = Modifier.weight(1f),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        text = if (pkg.flagged) {
                            stringResource(R.string.logs_badge_flagged)
                        } else {
                            stringResource(R.string.logs_badge_clean)
                        },
                        style = MaterialTheme.typography.labelLarge.copy(fontSize = 11.sp),
                        color = badgeColor
                    )
                }
                Text(
                    text = pkg.packageName,
                    style = MaterialTheme.typography.bodyMedium.copy(
                        fontFamily = FontFamily.Monospace,
                        fontSize = 11.sp
                    ),
                    color = colors.textSecondary,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                if (!pkg.matchReason.isNullOrBlank()) {
                    Text(
                        text = pkg.matchReason,
                        style = MaterialTheme.typography.bodyMedium.copy(fontSize = 11.sp),
                        color = colors.statusAmber
                    )
                }
            }
        }
    }
}

@Composable
private fun FileLogRow(file: ScannedFileLog) {
    val colors = LocalFFColors.current
    val badgeColor = if (file.flagged) colors.statusAmber else colors.statusGreen
    Surface(
        modifier = Modifier.fillMaxWidth(),
        color = colors.surface,
        shape = RoundedCornerShape(12.dp),
        border = BorderStroke(
            width = colors.borderWidth,
            color = if (file.flagged) colors.statusAmber.copy(alpha = 0.7f) else colors.border
        )
    ) {
        Column(
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(
                    imageVector = Icons.Outlined.Description,
                    contentDescription = null,
                    tint = badgeColor,
                    modifier = Modifier.size(16.dp)
                )
                Text(
                    text = file.fileName,
                    style = MaterialTheme.typography.labelLarge.copy(
                        fontSize = 13.sp,
                        fontWeight = FontWeight.SemiBold
                    ),
                    color = colors.textPrimary,
                    modifier = Modifier.weight(1f),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    text = formatByteSize(file.sizeBytes),
                    style = MaterialTheme.typography.bodyMedium.copy(
                        fontFamily = FontFamily.Monospace,
                        fontSize = 11.sp
                    ),
                    color = colors.textSecondary
                )
            }
            Text(
                text = file.relativePath,
                style = MaterialTheme.typography.bodyMedium.copy(
                    fontFamily = FontFamily.Monospace,
                    fontSize = 11.sp
                ),
                color = colors.textSecondary
            )
            if (!file.matchReason.isNullOrBlank()) {
                Text(
                    text = file.matchReason,
                    style = MaterialTheme.typography.bodyMedium.copy(fontSize = 11.sp),
                    color = colors.statusAmber
                )
            }
        }
    }
}

private fun formatByteSize(bytes: Long): String {
    return when {
        bytes < 1024L -> "$bytes B"
        bytes < 1024L * 1024L -> "${bytes / 1024L} KB"
        else -> String.format(Locale.US, "%.1f MB", bytes / (1024f * 1024f))
    }
}

private fun buildRawLogsText(result: ScanResult): String {
    val dateStr = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US)
        .format(Date(result.timestampMillis))
    return buildString {
        appendLine("=== FF Scanner Execution Logs ($dateStr) ===")
        appendLine("Packages checked: ${result.scannedPackages.size}")
        result.scannedPackages.forEach { pkg ->
            val flag = if (pkg.flagged) "FLAGGED" else "OK"
            appendLine("[$flag] ${pkg.packageName} (${pkg.appLabel})")
        }
        appendLine()
        appendLine("Files logged: ${result.scannedFiles.size} / ${result.totalFilesChecked}")
        result.scannedFiles.forEach { f ->
            val flag = if (f.flagged) "FLAGGED" else "OK"
            appendLine("[$flag] ${f.relativePath} (${f.sizeBytes} bytes)")
        }
    }
}
