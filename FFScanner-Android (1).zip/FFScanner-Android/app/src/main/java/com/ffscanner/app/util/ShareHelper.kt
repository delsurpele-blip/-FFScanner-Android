package com.ffscanner.app.util

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.net.Uri
import android.provider.Settings
import androidx.core.content.FileProvider
import com.ffscanner.app.R
import com.ffscanner.app.model.FindingSeverity
import com.ffscanner.app.model.OverallStatus
import com.ffscanner.app.model.ScanResult
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object ShareHelper {

    fun openAppDetailsSettings(context: Context, packageName: String) {
        val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
            data = Uri.fromParts("package", packageName, null)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(intent)
    }

    fun buildTextReport(context: Context, result: ScanResult): String {
        val dateStr = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault())
            .format(Date(result.timestampMillis))

        val headerStatus = when (result.overallStatus) {
            OverallStatus.CLEAN -> context.getString(R.string.share_report_clean_count)
            OverallStatus.REVIEW_ALERTS -> context.getString(R.string.status_review_count, result.alertCount)
            OverallStatus.INCOMPLETE -> context.getString(R.string.status_incomplete)
        }

        return buildString {
            appendLine(context.getString(R.string.share_report_header))
            appendLine(context.getString(R.string.share_report_date, dateStr))
            appendLine(context.getString(R.string.share_report_result, headerStatus))
            appendLine(context.getString(R.string.share_report_apps_checked, result.totalAppsChecked))
            appendLine(context.getString(R.string.share_report_files_checked, result.totalFilesChecked))
            appendLine()
            appendLine(context.getString(R.string.share_report_ff_section))
            result.freeFireStatuses.forEach { ff ->
                if (ff.installed) {
                    val mark = if (ff.isOfficialStore) {
                        context.getString(R.string.severity_ok)
                    } else {
                        context.getString(R.string.severity_alert).uppercase(Locale.getDefault())
                    }
                    appendLine("[$mark] ${ff.displayName}: ${ff.installerName}")
                } else {
                    appendLine("[--] ${ff.displayName}: ${context.getString(R.string.ff_not_installed)}")
                }
            }
            if (result.findings.isNotEmpty()) {
                appendLine()
                appendLine(context.getString(R.string.share_report_findings_section, result.findings.size))
                result.findings.forEachIndexed { idx, finding ->
                    val categoryLabel = context.getString(finding.category.labelRes)
                    appendLine("${idx + 1}. [$categoryLabel] ${finding.title}")
                    appendLine("   ${context.getString(R.string.share_report_detail, finding.subtitle)}")
                    appendLine("   ${context.getString(R.string.results_reason_format, finding.reason)}")
                }
            }
            if (result.incompleteReasons.isNotEmpty()) {
                appendLine()
                appendLine(context.getString(R.string.share_report_pending_section))
                result.incompleteReasons.forEach { appendLine("- $it") }
            }
            appendLine()
            appendLine(context.getString(R.string.fixed_disclaimer))
        }
    }

    fun shareAsText(context: Context, result: ScanResult) {
        val text = buildTextReport(context, result)
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_SUBJECT, context.getString(R.string.share_subject))
            putExtra(Intent.EXTRA_TEXT, text)
        }
        context.startActivity(
            Intent.createChooser(intent, context.getString(R.string.share_chooser_text))
        )
    }

    fun shareAsScreenshot(context: Context, result: ScanResult) {
        val bitmap = renderSummaryBitmap(context, result)
        val reportsDir = File(context.cacheDir, "reports").apply { mkdirs() }
        val file = File(reportsDir, "ff_scanner_resultado.png")
        FileOutputStream(file).use { out ->
            bitmap.compress(Bitmap.CompressFormat.PNG, 100, out)
        }
        val uri = FileProvider.getUriForFile(
            context,
            "${context.packageName}.fileprovider",
            file
        )
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "image/png"
            putExtra(Intent.EXTRA_STREAM, uri)
            putExtra(Intent.EXTRA_TEXT, context.getString(R.string.share_image_caption))
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        context.startActivity(
            Intent.createChooser(intent, context.getString(R.string.share_chooser_image))
        )
    }

    private fun renderSummaryBitmap(context: Context, result: ScanResult): Bitmap {
        val width = 1080
        val maxFindingsToDraw = result.findings.take(8)
        val height = 760 + (maxFindingsToDraw.size * 124)
        val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)

        // Fondo #0A1128
        canvas.drawColor(Color.parseColor("#0A1128"))

        val cardPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#121D3E")
        }
        val borderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeWidth = 3f
            color = Color.parseColor("#243970")
        }

        val statusColor = when {
            result.overallStatus == OverallStatus.INCOMPLETE -> Color.parseColor("#F59E0B")
            result.alertCount == 0 -> Color.parseColor("#22C55E")
            result.findings.any { it.severity == FindingSeverity.ALERT } -> Color.parseColor("#EF4444")
            else -> Color.parseColor("#F59E0B")
        }

        val titlePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            textSize = 52f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        }
        val subPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#9FB4DF")
            textSize = 30f
        }
        val statusPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = statusColor
            textSize = 48f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        }

        canvas.drawText(context.getString(R.string.app_name), 64f, 96f, titlePaint)
        val dateStr = SimpleDateFormat("dd/MM/yyyy · HH:mm", Locale.getDefault())
            .format(Date(result.timestampMillis))
        canvas.drawText(
            context.getString(R.string.share_bitmap_subtitle, dateStr),
            64f,
            144f,
            subPaint
        )

        // Tarjeta de estado
        val statusRect = RectF(64f, 184f, width - 64f, 380f)
        canvas.drawRoundRect(statusRect, 28f, 28f, cardPaint)
        canvas.drawRoundRect(statusRect, 28f, 28f, borderPaint)

        val statusLabel = when (result.overallStatus) {
            OverallStatus.CLEAN -> context.getString(R.string.status_clean)
            OverallStatus.REVIEW_ALERTS -> context.getString(R.string.status_review_count, result.alertCount)
            OverallStatus.INCOMPLETE -> context.getString(R.string.status_incomplete)
        }
        canvas.drawText(statusLabel, 100f, 260f, statusPaint)
        canvas.drawText(
            context.getString(R.string.share_bitmap_counts, result.totalAppsChecked, result.totalFilesChecked),
            100f,
            325f,
            subPaint
        )

        // Free Fire resumen
        val ffRect = RectF(64f, 412f, width - 64f, 586f)
        canvas.drawRoundRect(ffRect, 24f, 24f, cardPaint)
        canvas.drawRoundRect(ffRect, 24f, 24f, borderPaint)

        val sectionPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#00D4FF")
            textSize = 30f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        }
        canvas.drawText(context.getString(R.string.share_bitmap_ff_title), 100f, 462f, sectionPaint)

        val bodyPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            textSize = 28f
        }
        result.freeFireStatuses.forEachIndexed { index, ff ->
            val y = 510f + index * 44f
            val line = "${ff.displayName}: ${ff.installerName}"
            canvas.drawText(line.take(56), 100f, y, bodyPaint)
        }

        // Hallazgos
        var currentY = 626f
        if (maxFindingsToDraw.isNotEmpty()) {
            canvas.drawText(
                context.getString(R.string.results_findings_header, result.findings.size),
                64f,
                currentY,
                sectionPaint
            )
            currentY += 28f
            maxFindingsToDraw.forEach { finding ->
                val itemRect = RectF(64f, currentY, width - 64f, currentY + 104f)
                canvas.drawRoundRect(itemRect, 20f, 20f, cardPaint)
                canvas.drawRoundRect(itemRect, 20f, 20f, borderPaint)

                val itemTitlePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    color = if (finding.severity == FindingSeverity.ALERT) {
                        Color.parseColor("#EF4444")
                    } else {
                        Color.parseColor("#F59E0B")
                    }
                    textSize = 28f
                    typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
                }
                canvas.drawText(finding.title.take(48), 96f, currentY + 44f, itemTitlePaint)
                canvas.drawText(finding.reason.take(62), 96f, currentY + 82f, subPaint)
                currentY += 120f
            }
        }

        val disclaimerPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#9FB4DF")
            textSize = 26f
        }
        canvas.drawText(
            context.getString(R.string.fixed_disclaimer),
            64f,
            height - 46f,
            disclaimerPaint
        )

        return bitmap
    }
}
