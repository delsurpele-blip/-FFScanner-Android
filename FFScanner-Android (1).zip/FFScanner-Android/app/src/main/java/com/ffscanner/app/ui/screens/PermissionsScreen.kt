package com.ffscanner.app.ui.screens

import android.Manifest
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Apps
import androidx.compose.material.icons.outlined.CheckCircle
import androidx.compose.material.icons.outlined.Contrast
import androidx.compose.material.icons.outlined.FolderCopy
import androidx.compose.material.icons.outlined.Terminal
import androidx.compose.material.icons.outlined.WarningAmber
import androidx.compose.material.icons.outlined.Wifi
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.ffscanner.app.R
import com.ffscanner.app.scanner.DeviceScanner
import com.ffscanner.app.ui.components.PressablePrimaryButton
import com.ffscanner.app.ui.components.PressableSecondaryButton
import com.ffscanner.app.ui.theme.LocalFFColors

@Composable
fun PermissionsScreen(
    highContrastMode: Boolean,
    onToggleHighContrast: (Boolean) -> Unit,
    advancedLogsUnlocked: Boolean,
    onUnlockAdvancedLogs: () -> Unit,
    onOpenAdvancedLogs: () -> Unit,
    onContinue: () -> Unit
) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val colors = LocalFFColors.current
    var permState by remember { mutableStateOf(DeviceScanner.getPermissionState(context)) }
    var secretTapCount by remember { mutableIntStateOf(0) }

    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) {
                permState = DeviceScanner.getPermissionState(context)
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose {
            lifecycleOwner.lifecycle.removeObserver(observer)
        }
    }

    val legacyStorageLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) {
        permState = DeviceScanner.getPermissionState(context)
    }

    val requestAllFilesAccess = {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            try {
                val intent = Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION).apply {
                    data = Uri.parse("package:${context.packageName}")
                }
                context.startActivity(intent)
            } catch (_: Exception) {
                val fallback = Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION)
                context.startActivity(fallback)
            }
        } else {
            legacyStorageLauncher.launch(Manifest.permission.READ_EXTERNAL_STORAGE)
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(colors.background)
            .statusBarsPadding()
            .navigationBarsPadding()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp, vertical = 20.dp),
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
            Text(
                text = stringResource(R.string.permissions_title),
                style = MaterialTheme.typography.headlineMedium,
                color = colors.textPrimary
            )
            Text(
                text = stringResource(R.string.permissions_subtitle, permState.androidVersionLabel),
                style = MaterialTheme.typography.bodyMedium,
                color = colors.textSecondary
            )

            // Interruptor de tema: azul oscuro vs alto contraste para exteriores
            Surface(
                modifier = Modifier.fillMaxWidth(),
                color = colors.surface,
                shape = RoundedCornerShape(16.dp),
                border = BorderStroke(colors.borderWidth, colors.border)
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Icon(
                        imageVector = Icons.Outlined.Contrast,
                        contentDescription = null,
                        tint = colors.accent,
                        modifier = Modifier.size(24.dp)
                    )
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = stringResource(R.string.theme_high_contrast_title),
                            style = MaterialTheme.typography.titleMedium,
                            color = colors.textPrimary
                        )
                        Text(
                            text = if (highContrastMode) {
                                stringResource(R.string.theme_high_contrast_on)
                            } else {
                                stringResource(R.string.theme_high_contrast_off)
                            },
                            style = MaterialTheme.typography.bodyMedium,
                            color = colors.textSecondary
                        )
                    }
                    Switch(
                        checked = highContrastMode,
                        onCheckedChange = onToggleHighContrast,
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = Color.White,
                            checkedTrackColor = colors.primary,
                            uncheckedThumbColor = colors.textSecondary,
                            uncheckedTrackColor = colors.surfaceElevated,
                            uncheckedBorderColor = colors.border
                        )
                    )
                }
            }

            // Permiso 1: QUERY_ALL_PACKAGES
            Surface(
                modifier = Modifier.fillMaxWidth(),
                color = colors.surface,
                shape = RoundedCornerShape(16.dp),
                border = BorderStroke(colors.borderWidth, colors.border)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Outlined.Apps,
                            contentDescription = null,
                            tint = colors.accent,
                            modifier = Modifier.size(24.dp)
                        )
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = stringResource(R.string.permissions_packages_title),
                                style = MaterialTheme.typography.titleMedium,
                                color = colors.textPrimary
                            )
                            Text(
                                text = if (permState.hasPackageQueryAccess) {
                                    stringResource(R.string.permissions_packages_active)
                                } else {
                                    stringResource(R.string.permissions_packages_limited)
                                },
                                style = MaterialTheme.typography.bodyMedium,
                                color = if (permState.hasPackageQueryAccess) colors.statusGreen else colors.statusAmber
                            )
                        }
                        Icon(
                            imageVector = if (permState.hasPackageQueryAccess) {
                                Icons.Outlined.CheckCircle
                            } else {
                                Icons.Outlined.WarningAmber
                            },
                            contentDescription = null,
                            tint = if (permState.hasPackageQueryAccess) colors.statusGreen else colors.statusAmber
                        )
                    }
                    Text(
                        text = stringResource(R.string.permissions_packages_desc),
                        style = MaterialTheme.typography.bodyMedium,
                        color = colors.textSecondary
                    )
                }
            }

            // Permiso 2: Internet y Wi-Fi
            Surface(
                modifier = Modifier.fillMaxWidth(),
                color = colors.surface,
                shape = RoundedCornerShape(16.dp),
                border = BorderStroke(colors.borderWidth, colors.border)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Outlined.Wifi,
                            contentDescription = null,
                            tint = colors.accent,
                            modifier = Modifier.size(24.dp)
                        )
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = stringResource(R.string.permissions_network_title),
                                style = MaterialTheme.typography.titleMedium,
                                color = colors.textPrimary
                            )
                            Text(
                                text = if (permState.hasInternetAndWifiAccess) {
                                    stringResource(
                                        R.string.permissions_network_active,
                                        permState.networkStatusLabel
                                    )
                                } else {
                                    stringResource(R.string.permissions_network_pending)
                                },
                                style = MaterialTheme.typography.bodyMedium,
                                color = if (permState.hasInternetAndWifiAccess) colors.statusGreen else colors.statusAmber
                            )
                        }
                        Icon(
                            imageVector = if (permState.hasInternetAndWifiAccess) {
                                Icons.Outlined.CheckCircle
                            } else {
                                Icons.Outlined.WarningAmber
                            },
                            contentDescription = null,
                            tint = if (permState.hasInternetAndWifiAccess) colors.statusGreen else colors.statusAmber
                        )
                    }
                    Text(
                        text = stringResource(R.string.permissions_network_desc),
                        style = MaterialTheme.typography.bodyMedium,
                        color = colors.textSecondary
                    )
                }
            }

            // Permiso 3: MANAGE_EXTERNAL_STORAGE / READ_EXTERNAL_STORAGE
            Surface(
                modifier = Modifier.fillMaxWidth(),
                color = colors.surface,
                shape = RoundedCornerShape(16.dp),
                border = BorderStroke(colors.borderWidth, colors.border)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Outlined.FolderCopy,
                            contentDescription = null,
                            tint = colors.accent,
                            modifier = Modifier.size(24.dp)
                        )
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                                    stringResource(R.string.permissions_files_title)
                                } else {
                                    stringResource(R.string.permissions_storage_read_title)
                                },
                                style = MaterialTheme.typography.titleMedium,
                                color = colors.textPrimary
                            )
                            Text(
                                text = if (permState.hasAllFilesAccess) {
                                    stringResource(R.string.permissions_status_granted)
                                } else {
                                    stringResource(R.string.permissions_status_pending)
                                },
                                style = MaterialTheme.typography.bodyMedium,
                                color = if (permState.hasAllFilesAccess) colors.statusGreen else colors.statusAmber
                            )
                        }
                        Icon(
                            imageVector = if (permState.hasAllFilesAccess) {
                                Icons.Outlined.CheckCircle
                            } else {
                                Icons.Outlined.WarningAmber
                            },
                            contentDescription = null,
                            tint = if (permState.hasAllFilesAccess) colors.statusGreen else colors.statusAmber
                        )
                    }
                    Text(
                        text = stringResource(R.string.permissions_files_desc),
                        style = MaterialTheme.typography.bodyMedium,
                        color = colors.textSecondary
                    )

                    if (!permState.hasAllFilesAccess) {
                        PressablePrimaryButton(
                            text = stringResource(R.string.permissions_grant_files_button),
                            onClick = requestAllFilesAccess,
                            containerColor = colors.primary,
                            modifier = Modifier.fillMaxWidth()
                        )
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                            Text(
                                text = stringResource(R.string.permissions_android13_note),
                                style = MaterialTheme.typography.bodyMedium,
                                color = colors.textSecondary
                            )
                            PressableSecondaryButton(
                                text = stringResource(R.string.permissions_open_app_info_button),
                                onClick = {
                                    val infoIntent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
                                        data = Uri.fromParts("package", context.packageName, null)
                                    }
                                    context.startActivity(infoIntent)
                                },
                                modifier = Modifier.fillMaxWidth()
                            )
                        }
                    }
                }
            }
        }

        Column(
            modifier = Modifier.padding(top = 20.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            if (advancedLogsUnlocked) {
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    color = colors.surface,
                    shape = RoundedCornerShape(16.dp),
                    border = BorderStroke(colors.borderWidth, colors.accent.copy(alpha = 0.65f))
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Outlined.Terminal,
                                contentDescription = null,
                                tint = colors.accent,
                                modifier = Modifier.size(20.dp)
                            )
                            Text(
                                text = stringResource(R.string.permissions_advanced_section_title),
                                style = MaterialTheme.typography.titleMedium,
                                color = colors.textPrimary
                            )
                        }
                        Text(
                            text = stringResource(R.string.permissions_advanced_section_desc),
                            style = MaterialTheme.typography.bodyMedium,
                            color = colors.textSecondary
                        )
                        PressableSecondaryButton(
                            text = stringResource(R.string.permissions_advanced_open_button),
                            onClick = onOpenAdvancedLogs,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }
            }

            if (permState.hasAllFilesAccess) {
                PressablePrimaryButton(
                    text = stringResource(R.string.permissions_continue_ready),
                    onClick = onContinue,
                    modifier = Modifier.fillMaxWidth()
                )
            } else {
                PressableSecondaryButton(
                    text = stringResource(R.string.permissions_continue_partial),
                    onClick = onContinue,
                    modifier = Modifier.fillMaxWidth()
                )
                Text(
                    text = stringResource(R.string.permissions_partial_warning),
                    style = MaterialTheme.typography.bodyMedium,
                    color = colors.statusAmber
                )
            }

            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable(
                        interactionSource = remember { MutableInteractionSource() },
                        indication = null
                    ) {
                        if (advancedLogsUnlocked) {
                            onOpenAdvancedLogs()
                        } else {
                            val next = secretTapCount + 1
                            if (next >= 5) {
                                secretTapCount = 0
                                onUnlockAdvancedLogs()
                                onOpenAdvancedLogs()
                            } else {
                                secretTapCount = next
                            }
                        }
                    }
                    .padding(vertical = 6.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = stringResource(
                        R.string.permissions_advanced_footer,
                        permState.androidVersionLabel
                    ),
                    style = MaterialTheme.typography.bodyMedium.copy(fontSize = 11.sp),
                    color = colors.textSecondary.copy(alpha = 0.72f),
                    textAlign = TextAlign.Center
                )
                if (!advancedLogsUnlocked && secretTapCount in 2..4) {
                    Text(
                        text = stringResource(
                            R.string.permissions_advanced_taps_hint,
                            5 - secretTapCount
                        ),
                        style = MaterialTheme.typography.bodyMedium.copy(fontSize = 11.sp),
                        color = colors.accent,
                        textAlign = TextAlign.Center
                    )
                }
            }
            Spacer(modifier = Modifier.height(4.dp))
        }
    }
}
