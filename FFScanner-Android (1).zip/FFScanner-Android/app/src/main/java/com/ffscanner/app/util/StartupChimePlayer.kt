package com.ffscanner.app.util

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioTrack
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import kotlin.math.PI
import kotlin.math.exp
import kotlin.math.sin

object StartupChimePlayer {

    private const val SAMPLE_RATE = 44_100
    private const val DURATION_SECONDS = 0.56f

    suspend fun playSubtleEntranceChime(context: Context) = withContext(Dispatchers.Default) {
        val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager
        if (audioManager != null && audioManager.ringerMode != AudioManager.RINGER_MODE_NORMAL) {
            return@withContext
        }

        val samples = generateFineChimePcm()
        var track: AudioTrack? = null
        try {
            val attributes = AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_ASSISTANCE_SONIFICATION)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build()

            val format = AudioFormat.Builder()
                .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                .setSampleRate(SAMPLE_RATE)
                .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                .build()

            track = AudioTrack.Builder()
                .setAudioAttributes(attributes)
                .setAudioFormat(format)
                .setBufferSizeInBytes(samples.size * 2)
                .setTransferMode(AudioTrack.MODE_STATIC)
                .build()

            if (track.state != AudioTrack.STATE_INITIALIZED) {
                return@withContext
            }

            track.write(samples, 0, samples.size)
            track.play()
            delay((DURATION_SECONDS * 1000).toLong() + 40L)
        } catch (_: Exception) {
            // Omitir silenciosamente si el dispositivo restringe la salida de audio
        } finally {
            runCatching {
                track?.stop()
            }
            runCatching {
                track?.release()
            }
        }
    }

    private fun generateFineChimePcm(): ShortArray {
        val totalSamples = (SAMPLE_RATE * DURATION_SECONDS).toInt()
        val buffer = ShortArray(totalSamples)
        val noteTwoStart = 0.115f
        val fadeOutStart = DURATION_SECONDS - 0.055f
        val maxGain = 0.20f

        for (i in 0 until totalSamples) {
            val t = i.toFloat() / SAMPLE_RATE

            // Primera nota cristalina: La5 (880 Hz)
            val env1 = smoothAttack(t, 0.008f) * exp(-t * 9.0f)
            val wave1 = (sin(2.0 * PI * 880.0 * t) + 0.16 * sin(2.0 * PI * 1760.0 * t)).toFloat() * env1

            // Segunda nota ascendente (quinta justa): Mi6 (1318.51 Hz) con destello armónico suave
            var wave2 = 0f
            if (t >= noteTwoStart) {
                val dt = t - noteTwoStart
                val env2 = smoothAttack(dt, 0.009f) * exp(-dt * 6.4f)
                wave2 = (
                    sin(2.0 * PI * 1318.51 * dt) +
                        0.18 * sin(2.0 * PI * 2637.02 * dt)
                    ).toFloat() * env2
            }

            val tailFade = if (t > fadeOutStart) {
                ((DURATION_SECONDS - t) / (DURATION_SECONDS - fadeOutStart)).coerceIn(0f, 1f)
            } else {
                1f
            }

            val mixed = ((wave1 * 0.62f + wave2 * 0.78f) * maxGain * tailFade).coerceIn(-1f, 1f)
            buffer[i] = (mixed * Short.MAX_VALUE).toInt().toShort()
        }
        return buffer
    }

    private fun smoothAttack(elapsed: Float, attackSeconds: Float): Float {
        return if (elapsed < attackSeconds) {
            (elapsed / attackSeconds).coerceIn(0f, 1f)
        } else {
            1f
        }
    }
}
