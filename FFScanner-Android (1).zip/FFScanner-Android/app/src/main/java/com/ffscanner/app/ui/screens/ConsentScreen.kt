package com.ffscanner.app.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.FolderOpen
import androidx.compose.material.icons.outlined.Lock
import androidx.compose.material.icons.outlined.PhonelinkSetup
import androidx.compose.material.icons.outlined.Wifi
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.ffscanner.app.R
import com.ffscanner.app.ui.components.PressablePrimaryButton
import com.ffscanner.app.ui.components.ShieldMagnifierEmblem
import com.ffscanner.app.ui.theme.LocalFFColors

@Composable
fun ConsentScreen(onAccept: () -> Unit) {
    val colors = LocalFFColors.current

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(colors.background)
            .statusBarsPadding()
            .navigationBarsPadding()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp, vertical = 20.dp),
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                ShieldMagnifierEmblem(size = 52.dp, glowAlpha = 0.35f)
                Column {
                    Text(
                        text = stringResource(R.string.consent_title),
                        style = MaterialTheme.typography.headlineMedium,
                        color = colors.textPrimary
                    )
                    Text(
                        text = stringResource(R.string.consent_subtitle),
                        style = MaterialTheme.typography.bodyMedium,
                        color = colors.accent
                    )
                }
            }

            Text(
                text = stringResource(R.string.consent_intro),
                style = MaterialTheme.typography.bodyLarge,
                color = colors.textPrimary
            )

            ConsentItemCard(
                icon = Icons.Outlined.Wifi,
                iconTint = colors.statusGreen,
                title = stringResource(R.string.consent_item_local_title),
                description = stringResource(R.string.consent_item_local_desc)
            )

            ConsentItemCard(
                icon = Icons.Outlined.PhonelinkSetup,
                iconTint = colors.accent,
                title = stringResource(R.string.consent_item_checks_title),
                description = stringResource(R.string.consent_item_checks_desc)
            )

            ConsentItemCard(
                icon = Icons.Outlined.FolderOpen,
                iconTint = colors.accent,
                title = stringResource(R.string.consent_item_protected_title),
                description = stringResource(R.string.consent_item_protected_desc)
            )

            ConsentItemCard(
                icon = Icons.Outlined.Lock,
                iconTint = colors.statusGreen,
                title = stringResource(R.string.consent_item_no_hidden_title),
                description = stringResource(R.string.consent_item_no_hidden_desc)
            )
        }

        Column(modifier = Modifier.padding(top = 20.dp)) {
            PressablePrimaryButton(
                text = stringResource(R.string.consent_accept_button),
                onClick = onAccept,
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(modifier = Modifier.height(6.dp))
        }
    }
}

@Composable
private fun ConsentItemCard(
    icon: ImageVector,
    iconTint: Color,
    title: String,
    description: String
) {
    val colors = LocalFFColors.current
    Surface(
        modifier = Modifier.fillMaxWidth(),
        color = colors.surface,
        shape = RoundedCornerShape(16.dp),
        border = BorderStroke(colors.borderWidth, colors.border)
    ) {
        Row(
            modifier = Modifier.padding(16.dp),
            horizontalArrangement = Arrangement.spacedBy(14.dp),
            verticalAlignment = Alignment.Top
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = iconTint,
                modifier = Modifier.size(24.dp)
            )
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleMedium,
                    color = colors.textPrimary
                )
                Text(
                    text = description,
                    style = MaterialTheme.typography.bodyMedium,
                    color = colors.textSecondary
                )
            }
        }
    }
}
