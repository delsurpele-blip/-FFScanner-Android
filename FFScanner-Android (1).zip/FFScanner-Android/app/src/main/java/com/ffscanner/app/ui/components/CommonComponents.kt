package com.ffscanner.app.ui.components

import android.content.pm.PackageManager
import android.os.Build
import android.view.HapticFeedbackConstants
import android.view.View
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Info
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.hapticfeedback.HapticFeedback
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.core.graphics.drawable.toBitmap
import com.ffscanner.app.R
import com.ffscanner.app.ui.theme.LocalFFColors
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

@Composable
fun ShieldMagnifierEmblem(
    modifier: Modifier = Modifier,
    size: Dp = 96.dp,
    glowAlpha: Float = 0.45f
) {
    val colors = LocalFFColors.current
    Canvas(modifier = modifier.size(size)) {
        val w = this.size.width
        val h = this.size.height
        val center = Offset(w / 2f, h / 2f)

        if (!colors.isHighContrast) {
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(
                        colors.primary.copy(alpha = glowAlpha),
                        colors.accent.copy(alpha = glowAlpha * 0.4f),
                        Color.Transparent
                    ),
                    center = center,
                    radius = w * 0.65f
                ),
                radius = w * 0.65f,
                center = center
            )
        }

        val shieldPath = Path().apply {
            moveTo(w * 0.50f, h * 0.14f)
            lineTo(w * 0.80f, h * 0.25f)
            lineTo(w * 0.80f, h * 0.50f)
            cubicTo(
                w * 0.80f, h * 0.69f,
                w * 0.67f, h * 0.82f,
                w * 0.50f, h * 0.88f
            )
            cubicTo(
                w * 0.33f, h * 0.82f,
                w * 0.20f, h * 0.69f,
                w * 0.20f, h * 0.50f
            )
            lineTo(w * 0.20f, h * 0.25f)
            close()
        }

        drawPath(
            path = shieldPath,
            brush = Brush.verticalGradient(
                colors = if (colors.isHighContrast) {
                    listOf(colors.primary, colors.primary)
                } else {
                    listOf(colors.primary, Color(0xFF10378A))
                }
            )
        )
        drawPath(
            path = shieldPath,
            color = if (colors.isHighContrast) colors.border else colors.accent.copy(alpha = 0.8f),
            style = Stroke(width = w * 0.028f)
        )

        val lensCenter = Offset(w * 0.47f, h * 0.48f)
        val lensRadius = w * 0.13f
        drawCircle(
            color = if (colors.isHighContrast) Color.White else colors.surface,
            radius = lensRadius,
            center = lensCenter
        )
        drawCircle(
            color = if (colors.isHighContrast) Color.White else colors.accent,
            radius = lensRadius,
            center = lensCenter,
            style = Stroke(width = w * 0.045f)
        )

        val handleStart = Offset(
            lensCenter.x + lensRadius * 0.72f,
            lensCenter.y + lensRadius * 0.72f
        )
        val handleEnd = Offset(w * 0.65f, h * 0.66f)
        drawLine(
            color = if (colors.isHighContrast) Color.White else colors.accent,
            start = handleStart,
            end = handleEnd,
            strokeWidth = w * 0.055f,
            cap = StrokeCap.Round
        )
    }
}

@Composable
fun PressablePrimaryButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    containerColor: Color? = null
) {
    val colors = LocalFFColors.current
    val resolvedContainer = containerColor ?: colors.primary
    val interactionSource = remember { MutableInteractionSource() }
    val isPressed by interactionSource.collectIsPressedAsState()
    val scale by animateFloatAsState(
        targetValue = if (isPressed) 0.96f else 1f,
        animationSpec = spring(stiffness = Spring.StiffnessMediumLow),
        label = "btnScale"
    )

    Button(
        onClick = onClick,
        enabled = enabled,
        interactionSource = interactionSource,
        shape = RoundedCornerShape(14.dp),
        colors = ButtonDefaults.buttonColors(
            containerColor = resolvedContainer,
            contentColor = Color.White,
            disabledContainerColor = colors.surfaceElevated,
            disabledContentColor = colors.textSecondary
        ),
        contentPadding = PaddingValues(horizontal = 24.dp, vertical = 14.dp),
        modifier = modifier
            .graphicsLayer {
                scaleX = scale
                scaleY = scale
            }
    ) {
        Text(
            text = text,
            style = MaterialTheme.typography.labelLarge
        )
    }
}

@Composable
fun PressableSecondaryButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val colors = LocalFFColors.current
    val interactionSource = remember { MutableInteractionSource() }
    val isPressed by interactionSource.collectIsPressedAsState()
    val scale by animateFloatAsState(
        targetValue = if (isPressed) 0.96f else 1f,
        animationSpec = spring(stiffness = Spring.StiffnessMediumLow),
        label = "secBtnScale"
    )

    OutlinedButton(
        onClick = onClick,
        interactionSource = interactionSource,
        shape = RoundedCornerShape(14.dp),
        border = BorderStroke(colors.borderWidth, colors.border),
        colors = ButtonDefaults.outlinedButtonColors(
            containerColor = colors.surface,
            contentColor = colors.textPrimary
        ),
        contentPadding = PaddingValues(horizontal = 20.dp, vertical = 14.dp),
        modifier = modifier
            .graphicsLayer {
                scaleX = scale
                scaleY = scale
            }
    ) {
        Text(
            text = text,
            style = MaterialTheme.typography.labelLarge
        )
    }
}

@Composable
fun FixedDisclaimerBanner(modifier: Modifier = Modifier) {
    val colors = LocalFFColors.current
    Surface(
        modifier = modifier.fillMaxWidth(),
        color = colors.surface,
        shape = RoundedCornerShape(12.dp),
        border = BorderStroke(colors.borderWidth, colors.border)
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Icon(
                imageVector = Icons.Outlined.Info,
                contentDescription = null,
                tint = colors.accent,
                modifier = Modifier.size(18.dp)
            )
            Text(
                text = stringResource(R.string.fixed_disclaimer),
                style = MaterialTheme.typography.bodyMedium,
                color = colors.textSecondary
            )
        }
    }
}

@Composable
fun AppPackageIcon(
    packageName: String?,
    fallbackIcon: ImageVector,
    fallbackTint: Color,
    modifier: Modifier = Modifier,
    size: Dp = 36.dp,
    apkFilePath: String? = null,
    packageManager: PackageManager = LocalContext.current.packageManager
) {
    val density = LocalDensity.current
    val iconPx = with(density) { size.roundToPx() }.coerceAtLeast(36)

    val appBitmap by produceState<ImageBitmap?>(
        initialValue = null,
        key1 = packageName,
        key2 = apkFilePath,
        key3 = iconPx
    ) {
        if (packageName.isNullOrBlank() && apkFilePath.isNullOrBlank()) {
            value = null
            return@produceState
        }
        value = withContext(Dispatchers.IO) {
            runCatching {
                val drawable = when {
                    !packageName.isNullOrBlank() -> packageManager.getApplicationIcon(packageName)
                    !apkFilePath.isNullOrBlank() && apkFilePath.endsWith(".apk", ignoreCase = true) -> {
                        val pkgInfo = packageManager.getPackageArchiveInfo(apkFilePath, 0)
                        val appInfo = pkgInfo?.applicationInfo?.apply {
                            sourceDir = apkFilePath
                            publicSourceDir = apkFilePath
                        }
                        appInfo?.loadIcon(packageManager)
                    }
                    else -> null
                }
                drawable?.toBitmap(width = iconPx, height = iconPx)?.asImageBitmap()
            }.getOrNull()
        }
    }

    val shape = RoundedCornerShape((size.value * 0.26f).dp)
    if (appBitmap != null) {
        Image(
            bitmap = appBitmap!!,
            contentDescription = null,
            contentScale = ContentScale.Crop,
            modifier = modifier
                .size(size)
                .clip(shape)
        )
    } else {
        Box(
            modifier = modifier
                .size(size)
                .clip(shape)
                .background(fallbackTint.copy(alpha = 0.14f))
                .border(1.dp, fallbackTint.copy(alpha = 0.45f), shape),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = fallbackIcon,
                contentDescription = null,
                tint = fallbackTint,
                modifier = Modifier.size(size * 0.56f)
            )
        }
    }
}

fun triggerShortHaptic(
    view: View,
    hapticFeedback: HapticFeedback,
    isStageCompletion: Boolean = false
) {
    val constant = if (isStageCompletion && Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
        HapticFeedbackConstants.CONFIRM
    } else {
        HapticFeedbackConstants.KEYBOARD_TAP
    }
    val performed = runCatching { view.performHapticFeedback(constant) }.getOrDefault(false)
    if (!performed) {
        runCatching {
            hapticFeedback.performHapticFeedback(HapticFeedbackType.LongPress)
        }
    }
}
