package com.ffscanner.app.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

@Immutable
data class FFScannerColors(
    val isHighContrast: Boolean,
    val background: Color,
    val surface: Color,
    val surfaceElevated: Color,
    val border: Color,
    val borderWidth: Dp,
    val primary: Color,
    val accent: Color,
    val textPrimary: Color,
    val textSecondary: Color,
    val statusGreen: Color,
    val statusAmber: Color,
    val statusRed: Color
)

val DarkBlueFFColors = FFScannerColors(
    isHighContrast = false,
    background = NavyBackground,
    surface = NavySurface,
    surfaceElevated = NavySurfaceElevated,
    border = NavyBorder,
    borderWidth = 1.dp,
    primary = ElectricBlue,
    accent = CyanAccent,
    textPrimary = TextWhite,
    textSecondary = TextMuted,
    statusGreen = StatusGreen,
    statusAmber = StatusAmber,
    statusRed = StatusRed
)

val HighContrastOutdoorFFColors = FFScannerColors(
    isHighContrast = true,
    background = OutdoorBackground,
    surface = OutdoorSurface,
    surfaceElevated = OutdoorSurfaceElevated,
    border = OutdoorBorder,
    borderWidth = 1.5.dp,
    primary = OutdoorBlue,
    accent = OutdoorCyan,
    textPrimary = OutdoorTextPrimary,
    textSecondary = OutdoorTextSecondary,
    statusGreen = OutdoorGreen,
    statusAmber = OutdoorAmber,
    statusRed = OutdoorRed
)

val LocalFFColors = staticCompositionLocalOf { DarkBlueFFColors }

private val DarkBlueMaterialScheme = darkColorScheme(
    primary = ElectricBlue,
    onPrimary = TextWhite,
    secondary = CyanAccent,
    onSecondary = NavyBackground,
    background = NavyBackground,
    onBackground = TextWhite,
    surface = NavySurface,
    onSurface = TextWhite,
    surfaceVariant = NavySurfaceElevated,
    onSurfaceVariant = TextMuted,
    outline = NavyBorder,
    error = StatusRed,
    onError = TextWhite
)

private val HighContrastMaterialScheme = lightColorScheme(
    primary = OutdoorBlue,
    onPrimary = Color.White,
    secondary = OutdoorCyan,
    onSecondary = Color.White,
    background = OutdoorBackground,
    onBackground = OutdoorTextPrimary,
    surface = OutdoorSurface,
    onSurface = OutdoorTextPrimary,
    surfaceVariant = OutdoorSurfaceElevated,
    onSurfaceVariant = OutdoorTextSecondary,
    outline = OutdoorBorder,
    error = OutdoorRed,
    onError = Color.White
)

@Composable
fun FFScannerTheme(
    highContrastMode: Boolean = false,
    content: @Composable () -> Unit
) {
    val palette = if (highContrastMode) HighContrastOutdoorFFColors else DarkBlueFFColors
    val colorScheme = if (highContrastMode) HighContrastMaterialScheme else DarkBlueMaterialScheme

    CompositionLocalProvider(LocalFFColors provides palette) {
        MaterialTheme(
            colorScheme = colorScheme,
            typography = FFScannerTypography,
            content = content
        )
    }
}
