package com.ffscanner.app

import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.ExperimentalSharedTransitionApi
import androidx.compose.animation.SharedTransitionLayout
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalContext
import com.ffscanner.app.model.AppScreen
import com.ffscanner.app.model.ScanProgress
import com.ffscanner.app.model.ScanResult
import com.ffscanner.app.model.ScanStage
import com.ffscanner.app.scanner.DeviceScanner
import com.ffscanner.app.ui.screens.AdvancedLogsScreen
import com.ffscanner.app.ui.screens.ConsentScreen
import com.ffscanner.app.ui.screens.HomeScreen
import com.ffscanner.app.ui.screens.PermissionsScreen
import com.ffscanner.app.ui.screens.ResultsScreen
import com.ffscanner.app.ui.screens.ScanningScreen
import com.ffscanner.app.ui.screens.SplashScreen
import com.ffscanner.app.ui.theme.FFScannerTheme
import com.ffscanner.app.ui.theme.LocalFFColors
import com.ffscanner.app.ui.theme.NavyBackground
import com.ffscanner.app.ui.theme.OutdoorBackground
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("ff_scanner_prefs", Context.MODE_PRIVATE)
        val initialHighContrast = prefs.getBoolean("high_contrast_mode", false)
        applySystemBars(initialHighContrast)

        setContent {
            var highContrastMode by remember { mutableStateOf(initialHighContrast) }

            LaunchedEffect(highContrastMode) {
                applySystemBars(highContrastMode)
            }

            FFScannerTheme(highContrastMode = highContrastMode) {
                FFScannerApp(
                    highContrastMode = highContrastMode,
                    onToggleHighContrast = { enabled ->
                        highContrastMode = enabled
                        prefs.edit().putBoolean("high_contrast_mode", enabled).apply()
                    }
                )
            }
        }
    }

    private fun applySystemBars(highContrast: Boolean) {
        if (highContrast) {
            val bg = OutdoorBackground.toArgb()
            enableEdgeToEdge(
                statusBarStyle = SystemBarStyle.light(bg, bg),
                navigationBarStyle = SystemBarStyle.light(bg, bg)
            )
        } else {
            val bg = NavyBackground.toArgb()
            enableEdgeToEdge(
                statusBarStyle = SystemBarStyle.dark(bg),
                navigationBarStyle = SystemBarStyle.dark(bg)
            )
        }
    }
}

@OptIn(ExperimentalSharedTransitionApi::class)
@Composable
private fun FFScannerApp(
    highContrastMode: Boolean,
    onToggleHighContrast: (Boolean) -> Unit
) {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("ff_scanner_prefs", Context.MODE_PRIVATE) }
    val scope = rememberCoroutineScope()
    val colors = LocalFFColors.current

    var currentScreen by remember { mutableStateOf(AppScreen.SPLASH) }
    var advancedLogsUnlocked by remember {
        mutableStateOf(prefs.getBoolean("advanced_logs_unlocked", false))
    }
    var permissionState by remember { mutableStateOf(DeviceScanner.getPermissionState(context)) }
    var scanProgress by remember {
        mutableStateOf(
            ScanProgress(
                percentage = 0,
                currentStage = ScanStage.FREE_FIRE,
                completedStages = emptySet(),
                statusDetail = context.getString(R.string.scan_status_initializing)
            )
        )
    }
    var scanResult by remember { mutableStateOf<ScanResult?>(null) }

    val startScan: () -> Unit = {
        permissionState = DeviceScanner.getPermissionState(context)
        scanProgress = ScanProgress(
            percentage = 0,
            currentStage = ScanStage.FREE_FIRE,
            completedStages = emptySet(),
            statusDetail = context.getString(R.string.scan_status_preparing)
        )
        currentScreen = AppScreen.SCANNING
        scope.launch {
            val result = DeviceScanner.runFullScan(context) { progress ->
                scanProgress = progress
            }
            scanResult = result
            currentScreen = AppScreen.RESULTS
        }
    }

    LaunchedEffect(currentScreen) {
        if (currentScreen == AppScreen.HOME) {
            permissionState = DeviceScanner.getPermissionState(context)
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(colors.background)
    ) {
        SharedTransitionLayout {
            val sharedTransitionScope = this
            AnimatedContent(
                targetState = currentScreen,
                transitionSpec = {
                    val isScanResultsTransition =
                        (initialState == AppScreen.SCANNING && targetState == AppScreen.RESULTS) ||
                        (initialState == AppScreen.RESULTS && targetState == AppScreen.SCANNING)

                    if (isScanResultsTransition) {
                        fadeIn(animationSpec = tween(420)) togetherWith
                            fadeOut(animationSpec = tween(320))
                    } else {
                        (fadeIn(animationSpec = tween(350)) + slideInHorizontally(
                            animationSpec = tween(350),
                            initialOffsetX = { fullWidth -> fullWidth / 5 }
                        )).togetherWith(
                            fadeOut(animationSpec = tween(320)) + slideOutHorizontally(
                                animationSpec = tween(320),
                                targetOffsetX = { fullWidth -> -fullWidth / 5 }
                            )
                        )
                    }
                },
                label = "screenTransition"
            ) { screen ->
                val animatedVisibilityScope = this
                when (screen) {
                    AppScreen.SPLASH -> {
                        SplashScreen(
                            onFinished = {
                                val accepted = prefs.getBoolean("consent_accepted", false)
                                currentScreen = if (accepted) AppScreen.HOME else AppScreen.CONSENT
                            }
                        )
                    }

                    AppScreen.CONSENT -> {
                        ConsentScreen(
                            onAccept = {
                                prefs.edit().putBoolean("consent_accepted", true).apply()
                                permissionState = DeviceScanner.getPermissionState(context)
                                currentScreen = AppScreen.PERMISSIONS
                            }
                        )
                    }

                    AppScreen.PERMISSIONS -> {
                        PermissionsScreen(
                            highContrastMode = highContrastMode,
                            onToggleHighContrast = onToggleHighContrast,
                            advancedLogsUnlocked = advancedLogsUnlocked,
                            onUnlockAdvancedLogs = {
                                advancedLogsUnlocked = true
                                prefs.edit().putBoolean("advanced_logs_unlocked", true).apply()
                            },
                            onOpenAdvancedLogs = { currentScreen = AppScreen.ADVANCED_LOGS },
                            onContinue = {
                                permissionState = DeviceScanner.getPermissionState(context)
                                currentScreen = AppScreen.HOME
                            }
                        )
                    }

                    AppScreen.HOME -> {
                        HomeScreen(
                            permissionState = permissionState,
                            onStartScan = startScan,
                            onOpenSettings = { currentScreen = AppScreen.PERMISSIONS }
                        )
                    }

                    AppScreen.SCANNING -> {
                        ScanningScreen(
                            progress = scanProgress,
                            sharedTransitionScope = sharedTransitionScope,
                            animatedVisibilityScope = animatedVisibilityScope
                        )
                    }

                    AppScreen.RESULTS -> {
                        val result = scanResult
                        if (result != null) {
                            ResultsScreen(
                                result = result,
                                onRescan = startScan,
                                sharedTransitionScope = sharedTransitionScope,
                                animatedVisibilityScope = animatedVisibilityScope
                            )
                        }
                    }

                    AppScreen.ADVANCED_LOGS -> {
                        AdvancedLogsScreen(
                            lastResult = scanResult,
                            onBack = { currentScreen = AppScreen.PERMISSIONS }
                        )
                    }
                }
            }
        }
    }
}
