package com.ffscanner.app.utils

import android.content.Context
import com.ffscanner.app.R
import com.ffscanner.app.model.FindingCategory
import com.ffscanner.app.model.FindingSeverity
import com.ffscanner.app.model.FreeFireStatus
import com.ffscanner.app.model.ScanFinding
import java.util.UUID

/**
 * Reglas locales de detección para FF Scanner.
 * Todo el filtrado se realiza sin conexión a internet comparando nombres de paquetes,
 * firmas conocidas de herramientas de trampa/malware y rutas locales de archivos.
 */
object SecurityLogic {

    const val PKG_FREE_FIRE = "com.dts.freefireth"
    const val PKG_FREE_FIRE_MAX = "com.dts.freefiremax"

    val OFFICIAL_STORES: Map<String, String> = mapOf(
        "com.android.vending" to "Google Play Store",
        "com.sec.android.app.samsungapps" to "Samsung Galaxy Store",
        "com.huawei.appmarket" to "Huawei AppGallery",
        "com.xiaomi.mipicks" to "Xiaomi GetApps",
        "com.xiaomi.market" to "Xiaomi GetApps"
    )

    /**
     * Firmas de paquetes conocidos de herramientas de modificación, root,
     * clonadores o software malicioso común en Android.
     */
    val KNOWN_THREAT_PACKAGE_SIGNATURES: Map<String, String> = mapOf(
        "catch_.me_.if_.you_.can_" to "GameGuardian (editor de memoria)",
        "com.gameguardian" to "GameGuardian",
        "com.chelpus.lackypatch" to "Lucky Patcher",
        "com.dimonvideo.luckypatcher" to "Lucky Patcher",
        "ru.sxbu.luckypatcher" to "Lucky Patcher",
        "com.forpda.lp" to "Lucky Patcher",
        "com.topjohnwu.magisk" to "Magisk Manager",
        "io.github.huskydg.magisk" to "Magisk Delta / Kitsune",
        "org.lsposed.manager" to "LSPosed Framework",
        "de.robv.android.xposed.installer" to "Xposed Installer",
        "com.vmos.pro" to "VMOS Pro (máquina virtual)",
        "com.vmos.glb" to "VMOS Global",
        "com.lbe.parallel.intl" to "Parallel Space",
        "com.ludashi.dualspace" to "Dual Space",
        "com.excelliance.dualaid" to "Clonador de aplicaciones",
        "com.truedevelopersstudio.automatictap.autoclicker" to "Auto Clicker",
        "com.opautoclicker.autoclicker" to "Auto Clicker"
    )

    val APP_SUSPICIOUS_KEYWORDS: List<String> = listOf(
        "hack",
        "cheat",
        "inject",
        "aimbot",
        "wallhack",
        "headshot",
        "regedit",
        "modmenu",
        "bypass",
        "gameguardian",
        "luckypatcher",
        "xposed",
        "lsposed",
        "magisk",
        "vmos",
        "parallel",
        "dualspace",
        "clone",
        "autoclick",
        "macro",
        "mod",
        "panel",
        "trojan",
        "spyware",
        "keylogger"
    )

    val HIGH_RISK_KEYWORDS: Set<String> = setOf(
        "hack",
        "cheat",
        "inject",
        "aimbot",
        "wallhack",
        "headshot",
        "modmenu",
        "bypass",
        "gameguardian",
        "luckypatcher",
        "lsposed",
        "xposed",
        "magisk",
        "trojan",
        "spyware",
        "keylogger"
    )

    val FILE_SUSPICIOUS_EXTENSIONS: Set<String> = setOf(
        "apk",
        "xapk",
        "apks",
        "obb"
    )

    val FILE_SUSPICIOUS_KEYWORDS: List<String> = listOf(
        "hack",
        "cheat",
        "inject",
        "aimbot",
        "bypass",
        "wallhack",
        "headshot",
        "regedit",
        "modmenu",
        "trojan",
        "spyware",
        "keylogger"
    )

    fun isExcludedStoragePath(relativeNormalizedPath: String): Boolean {
        val lower = relativeNormalizedPath.lowercase()
        return lower == "android/data" ||
            lower.startsWith("android/data/") ||
            lower == "android/obb" ||
            lower.startsWith("android/obb/")
    }

    fun evaluateFreeFireOrigin(
        context: Context,
        packageName: String,
        displayName: String,
        installed: Boolean,
        installerPackage: String?
    ): FreeFireStatus {
        if (!installed) {
            return FreeFireStatus(
                packageName = packageName,
                displayName = displayName,
                installed = false,
                installerPackage = null,
                installerName = context.getString(R.string.ff_not_installed),
                isOfficialStore = true
            )
        }

        val officialStoreName = installerPackage?.let { OFFICIAL_STORES[it] }
        val isOfficial = officialStoreName != null
        val readableInstaller = when {
            officialStoreName != null -> officialStoreName
            installerPackage.isNullOrBlank() -> context.getString(R.string.ff_unknown_installer)
            else -> context.getString(R.string.ff_unofficial_origin, installerPackage)
        }

        return FreeFireStatus(
            packageName = packageName,
            displayName = displayName,
            installed = true,
            installerPackage = installerPackage,
            installerName = readableInstaller,
            isOfficialStore = isOfficial
        )
    }

    fun evaluateInstalledApp(
        context: Context,
        label: String,
        packageName: String
    ): ScanFinding? {
        val pkgLower = packageName.lowercase()
        val labelLower = label.lowercase()

        val knownSignatureMatch = KNOWN_THREAT_PACKAGE_SIGNATURES.entries
            .firstOrNull { (sigPrefix, _) -> pkgLower.startsWith(sigPrefix) }

        val matchedInLabel = APP_SUSPICIOUS_KEYWORDS.filter { labelLower.contains(it) }
        val matchedInPkg = APP_SUSPICIOUS_KEYWORDS.filter { pkgLower.contains(it) }
        val allMatches = (matchedInLabel + matchedInPkg).distinct()

        if (knownSignatureMatch == null && allMatches.isEmpty()) {
            return null
        }

        val reason = buildString {
            if (knownSignatureMatch != null) {
                append(context.getString(R.string.finding_known_signature, knownSignatureMatch.value))
                if (allMatches.isNotEmpty()) append(" ")
            }
            if (allMatches.isNotEmpty()) {
                val where = when {
                    matchedInLabel.isNotEmpty() && matchedInPkg.isNotEmpty() ->
                        context.getString(R.string.finding_loc_both)
                    matchedInLabel.isNotEmpty() ->
                        context.getString(R.string.finding_loc_name)
                    else ->
                        context.getString(R.string.finding_loc_package)
                }
                append(
                    context.getString(
                        R.string.finding_keyword_in,
                        allMatches.joinToString(", "),
                        where
                    )
                )
            }
        }

        val severity = if (knownSignatureMatch != null || allMatches.any { it in HIGH_RISK_KEYWORDS }) {
            FindingSeverity.ALERT
        } else {
            FindingSeverity.REVIEW
        }

        return ScanFinding(
            id = UUID.randomUUID().toString(),
            title = label,
            subtitle = packageName,
            reason = reason,
            category = FindingCategory.SUSPICIOUS_APP,
            severity = severity,
            packageName = packageName
        )
    }

    fun evaluateLocalFile(
        context: Context,
        fileName: String,
        relativePath: String,
        extension: String,
        absolutePath: String
    ): ScanFinding? {
        val nameLower = fileName.lowercase()
        val extLower = extension.lowercase()

        val hasSuspiciousExt = extLower in FILE_SUSPICIOUS_EXTENSIONS
        val matchedFileWords = FILE_SUSPICIOUS_KEYWORDS.filter { nameLower.contains(it) }

        if (!hasSuspiciousExt && matchedFileWords.isEmpty()) {
            return null
        }

        val displayPath = if (relativePath.isNotEmpty()) relativePath else fileName
        val severity = if (matchedFileWords.isNotEmpty()) {
            FindingSeverity.ALERT
        } else {
            FindingSeverity.REVIEW
        }

        val reason = when {
            hasSuspiciousExt && matchedFileWords.isNotEmpty() ->
                context.getString(
                    R.string.finding_suspicious_pkg_with_kw,
                    extLower,
                    matchedFileWords.joinToString(", ")
                )
            hasSuspiciousExt ->
                context.getString(R.string.finding_loose_pkg, extLower)
            else ->
                context.getString(
                    R.string.finding_suspicious_filename,
                    matchedFileWords.joinToString(", ")
                )
        }

        return ScanFinding(
            id = UUID.randomUUID().toString(),
            title = fileName,
            subtitle = displayPath,
            reason = reason,
            category = FindingCategory.SUSPICIOUS_FILE,
            severity = severity,
            filePath = absolutePath
        )
    }
}
