package com.ffscanner.app.ui.screens

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.ffscanner.app.R
import com.ffscanner.app.ui.components.ShieldMagnifierEmblem
import com.ffscanner.app.ui.theme.LocalFFColors
import com.ffscanner.app.util.StartupChimePlayer
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@Composable
fun SplashScreen(onFinished: () -> Unit) {
    val context = LocalContext.current
    val colors = LocalFFColors.current
    val fullTitle = stringResource(R.string.app_name)
    var startZoom by remember { mutableStateOf(false) }
    var visibleChars by remember { mutableIntStateOf(0) }
    var showSubtitle by remember { mutableStateOf(false) }

    val shieldScale by animateFloatAsState(
        targetValue = if (startZoom) 1f else 0.45f,
        animationSpec = spring(
            dampingRatio = Spring.DampingRatioMediumBouncy,
            stiffness = Spring.StiffnessLow
        ),
        label = "splashZoom"
    )
    val shieldAlpha by animateFloatAsState(
        targetValue = if (startZoom) 1f else 0f,
        animationSpec = tween(durationMillis = 550, easing = FastOutSlowInEasing),
        label = "splashAlpha"
    )

    val infiniteTransition = rememberInfiniteTransition(label = "radarPulse")
    val radarWave1 by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 1900, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "wave1"
    )
    val radarWave2 by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 1900, delayMillis = 650, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "wave2"
    )
    val glowPulse by infiniteTransition.animateFloat(
        initialValue = 0.35f,
        targetValue = 0.80f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 900, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "glowPulse"
    )

    LaunchedEffect(Unit) {
        launch { StartupChimePlayer.playSubtleEntranceChime(context) }
        startZoom = true
        delay(350)
        for (i in 1..fullTitle.length) {
            visibleChars = i
            delay(85)
        }
        showSubtitle = true
        delay(1250)
        onFinished()
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(colors.background),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Box(
                modifier = Modifier.size(220.dp),
                contentAlignment = Alignment.Center
            ) {
                Canvas(modifier = Modifier.fillMaxSize()) {
                    val maxRadius = size.minDimension / 2f
                    listOf(radarWave1, radarWave2).forEach { progress ->
                        val radius = maxRadius * (0.35f + 0.65f * progress)
                        val alpha = (1f - progress).coerceIn(0f, 1f) * 0.45f
                        drawCircle(
                            color = colors.primary.copy(alpha = alpha),
                            radius = radius,
                            style = Stroke(width = 3.dp.toPx())
                        )
                    }
                }

                ShieldMagnifierEmblem(
                    size = 112.dp,
                    glowAlpha = glowPulse,
                    modifier = Modifier.graphicsLayer {
                        scaleX = shieldScale
                        scaleY = shieldScale
                        alpha = shieldAlpha
                    }
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            Text(
                text = fullTitle.take(visibleChars),
                style = MaterialTheme.typography.headlineLarge.copy(
                    fontSize = 34.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 0.5.sp
                ),
                color = colors.textPrimary
            )

            Spacer(modifier = Modifier.height(8.dp))

            val subAlpha by animateFloatAsState(
                targetValue = if (showSubtitle) 1f else 0f,
                animationSpec = tween(400),
                label = "subAlpha"
            )
            Text(
                text = stringResource(R.string.splash_subtitle),
                style = MaterialTheme.typography.bodyMedium,
                color = colors.accent,
                modifier = Modifier.alpha(subAlpha)
            )
        }
    }
}
