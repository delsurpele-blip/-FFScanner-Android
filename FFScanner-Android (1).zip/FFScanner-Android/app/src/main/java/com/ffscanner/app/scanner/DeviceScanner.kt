package com.ffscanner.app.scanner

import android.Manifest
import android.content.Context
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.Build
import android.os.Environment
import androidx.core.content.ContextCompat
import com.ffscanner.app.R
import com.ffscanner.app.model.FindingCategory
import com.ffscanner.app.model.FindingSeverity
import com.ffscanner.app.model.FreeFireStatus
import com.ffscanner.app.model.OverallStatus
import com.ffscanner.app.model.PermissionState
import com.ffscanner.app.model.ScanFinding
import com.ffscanner.app.model.ScanProgress
import com.ffscanner.app.model.ScanResult
import com.ffscanner.app.model.ScanStage
import com.ffscanner.app.model.ScannedFileLog
import com.ffscanner.app.model.ScannedPackageLog
import com.ffscanner.app.utils.SecurityLogic
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.delay
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import java.io.File
import java.util.UUID

object DeviceScanner {

    fun getPermissionState(context: Context): PermissionState {
        val pm = context.packageManager
        val installedCount = try {
            getInstalledApplicationsCompat(pm).size
        } catch (_: Exception) {
            0
        }
        val hasQueryAccess = installedCount > 1

        val hasFilesAccess = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            Environment.isExternalStorageManager()
        } else {
            ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.READ_EXTERNAL_STORAGE
            ) == PackageManager.PERMISSION_GRANTED
        }

        val hasInternet = ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.INTERNET
        ) == PackageManager.PERMISSION_GRANTED
        val hasNetworkState = ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.ACCESS_NETWORK_STATE
        ) == PackageManager.PERMISSION_GRANTED
        val hasWifiState = ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.ACCESS_WIFI_STATE
        ) == PackageManager.PERMISSION_GRANTED

        val networkStatusLabel = if (!hasNetworkState) {
            context.getString(R.string.network_perm_unavailable)
        } else {
            try {
                val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager
                val activeNetwork = cm?.activeNetwork
                val caps = activeNetwork?.let { cm.getNetworkCapabilities(it) }
                when {
                    caps == null -> context.getString(R.string.network_no_active)
                    caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) ->
                        context.getString(R.string.network_wifi)
                    caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) ->
                        context.getString(R.string.network_cellular)
                    else -> context.getString(R.string.network_connected)
                }
            } catch (_: Exception) {
                context.getString(R.string.network_perm_active)
            }
        }

        val versionLabel = "Android ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})"
        return PermissionState(
            hasPackageQueryAccess = hasQueryAccess,
            hasAllFilesAccess = hasFilesAccess,
            hasInternetAndWifiAccess = hasInternet && hasNetworkState && hasWifiState,
            networkStatusLabel = networkStatusLabel,
            androidVersionLabel = versionLabel
        )
    }

    suspend fun runFullScan(
        context: Context,
        onProgress: (ScanProgress) -> Unit
    ): ScanResult = withContext(Dispatchers.IO) {
        val pm = context.packageManager
        val findings = mutableListOf<ScanFinding>()
        val incompleteReasons = mutableListOf<String>()
        val completed = mutableSetOf<ScanStage>()
        val packageLogs = mutableListOf<ScannedPackageLog>()
        val fileLogs = mutableListOf<ScannedFileLog>()
        val maxFileLogsInMemory = 2_500
        var totalAppsChecked = 0
        var totalFilesChecked = 0

        suspend fun emitProgress(
            percentage: Int,
            stage: ScanStage,
            detail: String,
            isLoading: Boolean = true,
            targetName: String? = null
        ) {
            val alertCount = findings.count { it.severity != FindingSeverity.OK }
            val snapshot = ScanProgress(
                percentage = percentage.coerceIn(0, 100),
                currentStage = stage,
                completedStages = completed.toSet(),
                statusDetail = detail,
                isLoading = isLoading,
                appsChecked = totalAppsChecked,
                filesChecked = totalFilesChecked,
                alertsFound = alertCount,
                liveFindings = findings.takeLast(3).reversed(),
                currentTargetName = targetName
            )
            withContext(Dispatchers.Main) {
                onProgress(snapshot)
            }
        }

        // ETAPA 1: Free Fire y Free Fire MAX
        emitProgress(
            percentage = 10,
            stage = ScanStage.FREE_FIRE,
            detail = context.getString(R.string.scan_detail_ff_checking),
            targetName = SecurityLogic.PKG_FREE_FIRE
        )
        delay(380)

        val ffStatuses = listOf(
            inspectFreeFirePackage(context, pm, SecurityLogic.PKG_FREE_FIRE, "Free Fire"),
            inspectFreeFirePackage(context, pm, SecurityLogic.PKG_FREE_FIRE_MAX, "Free Fire MAX")
        )

        ffStatuses.filter { it.installed }.forEach { status ->
            val reason = if (!status.isOfficialStore) {
                context.getString(R.string.ff_modified_apk_reason, status.installerName)
            } else {
                null
            }
            packageLogs.add(
                ScannedPackageLog(
                    appLabel = status.displayName,
                    packageName = status.packageName,
                    flagged = !status.isOfficialStore,
                    matchReason = reason
                )
            )
            if (!status.isOfficialStore) {
                findings.add(
                    ScanFinding(
                        id = UUID.randomUUID().toString(),
                        title = context.getString(R.string.ff_modified_apk_title, status.displayName),
                        subtitle = status.packageName,
                        reason = reason.orEmpty(),
                        category = FindingCategory.FREE_FIRE,
                        severity = FindingSeverity.ALERT,
                        packageName = status.packageName
                    )
                )
                emitProgress(
                    percentage = 26,
                    stage = ScanStage.FREE_FIRE,
                    detail = context.getString(R.string.scan_detail_ff_alert, status.displayName),
                    targetName = status.packageName
                )
                delay(220)
            }
        }

        completed.add(ScanStage.FREE_FIRE)
        emitProgress(
            percentage = 34,
            stage = ScanStage.APPS,
            detail = context.getString(R.string.scan_detail_applying_rules)
        )
        delay(380)

        // ETAPA 2: Aplicaciones instaladas sospechosas (usando SecurityLogic)
        var couldInspectAllApps = true
        try {
            val allApps = getInstalledApplicationsCompat(pm)
            if (allApps.size <= 1) {
                couldInspectAllApps = false
                incompleteReasons.add(context.getString(R.string.incomplete_apps_access))
            } else {
                val thirdPartyApps = allApps.filter { app ->
                    val isSystem = (app.flags and ApplicationInfo.FLAG_SYSTEM) != 0
                    val isUpdatedSystem = (app.flags and ApplicationInfo.FLAG_UPDATED_SYSTEM_APP) != 0
                    !isSystem && !isUpdatedSystem && app.packageName != context.packageName
                }

                thirdPartyApps.forEachIndexed { index, appInfo ->
                    currentCoroutineContext().ensureActive()
                    totalAppsChecked = index + 1
                    val label = try {
                        pm.getApplicationLabel(appInfo).toString()
                    } catch (_: Exception) {
                        appInfo.packageName
                    }

                    val appFinding = SecurityLogic.evaluateInstalledApp(
                        context = context,
                        label = label,
                        packageName = appInfo.packageName
                    )
                    packageLogs.add(
                        ScannedPackageLog(
                            appLabel = label,
                            packageName = appInfo.packageName,
                            flagged = appFinding != null,
                            matchReason = appFinding?.reason
                        )
                    )
                    if (appFinding != null) {
                        findings.add(appFinding)
                        val pct = 34 + ((totalAppsChecked.toFloat() / thirdPartyApps.size.coerceAtLeast(1)) * 30).toInt()
                        emitProgress(
                            percentage = pct.coerceIn(34, 64),
                            stage = ScanStage.APPS,
                            detail = context.getString(R.string.scan_detail_signature_found, label),
                            targetName = appInfo.packageName
                        )
                    } else if (thirdPartyApps.isNotEmpty() && (index % 6 == 0 || index == thirdPartyApps.lastIndex)) {
                        val pct = 34 + ((totalAppsChecked.toFloat() / thirdPartyApps.size.coerceAtLeast(1)) * 30).toInt()
                        emitProgress(
                            percentage = pct.coerceIn(34, 64),
                            stage = ScanStage.APPS,
                            detail = context.getString(
                                R.string.scan_detail_apps_progress,
                                totalAppsChecked,
                                thirdPartyApps.size
                            ),
                            targetName = label
                        )
                    }
                }
            }
        } catch (e: Exception) {
            couldInspectAllApps = false
            val errReason = e.localizedMessage ?: context.getString(R.string.incomplete_perm_denied)
            incompleteReasons.add(context.getString(R.string.incomplete_apps_error, errReason))
        }

        completed.add(ScanStage.APPS)
        emitProgress(
            percentage = 66,
            stage = ScanStage.FILES,
            detail = context.getString(R.string.scan_detail_scanning_folders)
        )
        delay(350)

        // ETAPA 3: Archivos en almacenamiento externo (sin Android/data ni Android/obb)
        val permissionState = getPermissionState(context)
        var couldScanFiles = permissionState.hasAllFilesAccess

        if (!permissionState.hasAllFilesAccess) {
            incompleteReasons.add(context.getString(R.string.incomplete_files_missing))
            emitProgress(
                percentage = 92,
                stage = ScanStage.FILES,
                detail = context.getString(R.string.scan_detail_files_pending),
                isLoading = true
            )
            delay(350)
        } else {
            try {
                @Suppress("DEPRECATION")
                val rootDir = Environment.getExternalStorageDirectory()
                if (rootDir == null || !rootDir.exists() || !rootDir.canRead()) {
                    couldScanFiles = false
                    incompleteReasons.add(context.getString(R.string.incomplete_storage_unreadable))
                } else {
                    val rootPath = rootDir.absolutePath
                    val stack = ArrayDeque<File>()
                    stack.addLast(rootDir)
                    val maxFilesToInspect = 45_000

                    while (stack.isNotEmpty() && totalFilesChecked < maxFilesToInspect) {
                        currentCoroutineContext().ensureActive()
                        val current = stack.removeLast()
                        val relative = current.absolutePath
                            .removePrefix(rootPath)
                            .trimStart(File.separatorChar)
                            .replace(File.separatorChar, '/')

                        if (SecurityLogic.isExcludedStoragePath(relative)) {
                            continue
                        }

                        if (current.isDirectory) {
                            val children = try {
                                current.listFiles()
                            } catch (_: SecurityException) {
                                null
                            }
                            if (children != null) {
                                for (child in children) {
                                    stack.addLast(child)
                                }
                            }
                        } else if (current.isFile) {
                            totalFilesChecked++

                            val fileFinding = SecurityLogic.evaluateLocalFile(
                                context = context,
                                fileName = current.name,
                                relativePath = relative,
                                extension = current.extension,
                                absolutePath = current.absolutePath
                            )
                            val logPath = relative.ifEmpty { current.name }
                            if (fileFinding != null || fileLogs.size < maxFileLogsInMemory) {
                                fileLogs.add(
                                    ScannedFileLog(
                                        fileName = current.name,
                                        relativePath = logPath,
                                        sizeBytes = current.length(),
                                        flagged = fileFinding != null,
                                        matchReason = fileFinding?.reason
                                    )
                                )
                            }
                            if (fileFinding != null) {
                                findings.add(fileFinding)
                                val pct = 66 + ((totalFilesChecked.coerceAtMost(5000) / 5000f) * 30).toInt()
                                emitProgress(
                                    percentage = pct.coerceIn(66, 96),
                                    stage = ScanStage.FILES,
                                    detail = context.getString(R.string.scan_detail_suspicious_file, current.name),
                                    targetName = relative
                                )
                            } else if (totalFilesChecked % 200 == 0) {
                                val pct = 66 + ((totalFilesChecked.coerceAtMost(5000) / 5000f) * 30).toInt()
                                emitProgress(
                                    percentage = pct.coerceIn(66, 96),
                                    stage = ScanStage.FILES,
                                    detail = context.getString(R.string.scan_detail_files_progress, totalFilesChecked),
                                    targetName = relative
                                )
                            }
                        }
                    }
                }
            } catch (e: Exception) {
                couldScanFiles = false
                val errDetail = e.localizedMessage ?: context.getString(R.string.incomplete_read_error)
                incompleteReasons.add(context.getString(R.string.incomplete_files_interrupted, errDetail))
            }
        }

        completed.add(ScanStage.FILES)
        emitProgress(
            percentage = 100,
            stage = ScanStage.FILES,
            detail = context.getString(R.string.scan_detail_finished),
            isLoading = false
        )
        delay(350)

        val sortedFindings = findings.sortedByDescending { it.severity.ordinal }
        val sortedPackageLogs = packageLogs.sortedWith(
            compareByDescending<ScannedPackageLog> { it.flagged }.thenBy { it.packageName.lowercase() }
        )
        val sortedFileLogs = fileLogs.sortedWith(
            compareByDescending<ScannedFileLog> { it.flagged }.thenBy { it.relativePath.lowercase() }
        )
        val hasIncomplete = !couldInspectAllApps || !couldScanFiles || incompleteReasons.isNotEmpty()
        val alertCount = sortedFindings.count { it.severity != FindingSeverity.OK }

        val overallStatus = when {
            alertCount > 0 -> OverallStatus.REVIEW_ALERTS
            hasIncomplete -> OverallStatus.INCOMPLETE
            else -> OverallStatus.CLEAN
        }

        ScanResult(
            timestampMillis = System.currentTimeMillis(),
            overallStatus = overallStatus,
            findings = sortedFindings,
            freeFireStatuses = ffStatuses,
            totalAppsChecked = totalAppsChecked,
            totalFilesChecked = totalFilesChecked,
            couldInspectAllApps = couldInspectAllApps,
            couldScanFiles = couldScanFiles,
            incompleteReasons = incompleteReasons,
            scannedPackages = sortedPackageLogs,
            scannedFiles = sortedFileLogs
        )
    }

    private fun inspectFreeFirePackage(
        context: Context,
        pm: PackageManager,
        packageName: String,
        displayName: String
    ): FreeFireStatus {
        val isInstalled = try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                pm.getPackageInfo(packageName, PackageManager.PackageInfoFlags.of(0))
            } else {
                @Suppress("DEPRECATION")
                pm.getPackageInfo(packageName, 0)
            }
            true
        } catch (_: PackageManager.NameNotFoundException) {
            false
        } catch (_: Exception) {
            false
        }

        val installerPkg = if (isInstalled) {
            try {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                    val info = pm.getInstallSourceInfo(packageName)
                    info.installingPackageName ?: info.initiatingPackageName
                } else {
                    @Suppress("DEPRECATION")
                    pm.getInstallerPackageName(packageName)
                }
            } catch (_: Exception) {
                null
            }
        } else {
            null
        }

        return SecurityLogic.evaluateFreeFireOrigin(
            context = context,
            packageName = packageName,
            displayName = displayName,
            installed = isInstalled,
            installerPackage = installerPkg
        )
    }

    private fun getInstalledApplicationsCompat(pm: PackageManager): List<ApplicationInfo> {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            pm.getInstalledApplications(PackageManager.ApplicationInfoFlags.of(0))
        } else {
            @Suppress("DEPRECATION")
            pm.getInstalledApplications(0)
        }
    }
}
