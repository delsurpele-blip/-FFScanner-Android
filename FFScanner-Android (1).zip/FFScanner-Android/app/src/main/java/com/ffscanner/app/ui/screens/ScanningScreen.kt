package com.ffscanner.app.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.AnimatedVisibilityScope
import androidx.compose.animation.BoundsTransform
import androidx.compose.animation.ExperimentalSharedTransitionApi
import androidx.compose.animation.SharedTransitionScope
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.animateIntAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.slideInVertically
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.ErrorOutline
import androidx.compose.material.icons.outlined.WarningAmber
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.ffscanner.app.R
import com.ffscanner.app.model.FindingSeverity
import com.ffscanner.app.model.ScanFinding
import com.ffscanner.app.model.ScanProgress
import com.ffscanner.app.model.ScanStage
import com.ffscanner.app.ui.components.AppPackageIcon
import com.ffscanner.app.ui.components.triggerShortHaptic
import com.ffscanner.app.ui.theme.LocalFFColors
import com.ffscanner.app.utils.SecurityLogic
import kotlin.math.hypot

@OptIn(ExperimentalSharedTransitionApi::class)
@Composable
fun ScanningScreen(
    progress: ScanProgress,
    sharedTransitionScope: SharedTransitionScope,
    animatedVisibilityScope: AnimatedVisibilityScope
) {
    val colors = LocalFFColors.current
    val view = LocalView.current
    val haptic = LocalHapticFeedback.current
    var previousCompletedStages by remember { mutableStateOf(emptySet<ScanStage>()) }

    LaunchedEffect(progress.completedStages) {
        val newlyCompleted = progress.completedStages - previousCompletedStages
        if (newlyCompleted.isNotEmpty()) {
            triggerShortHaptic(view, haptic, isStageCompletion = true)
        }
        previousCompletedStages = progress.completedStages
    }

    val sharedBoundsTransform = remember {
        BoundsTransform { _, _ ->
            spring(
                dampingRatio = 0.82f,
                stiffness = Spring.StiffnessMediumLow
            )
        }
    }
    val animatedSweep by animateFloatAsState(
        targetValue = (progress.percentage / 100f).coerceIn(0f, 1f),
        animationSpec = tween(durationMillis = 360, easing = FastOutSlowInEasing),
        label = "sweepProgress"
    )
    val animatedPercent by animateIntAsState(
        targetValue = progress.percentage.coerceIn(0, 100),
        animationSpec = tween(durationMillis = 320),
        label = "percentInt"
    )
    val animatedAlerts by animateIntAsState(
        targetValue = progress.alertsFound,
        animationSpec = tween(durationMillis = 280),
        label = "liveAlertsInt"
    )

    val signatureRulesCount = SecurityLogic.KNOWN_THREAT_PACKAGE_SIGNATURES.size +
        SecurityLogic.APP_SUSPICIOUS_KEYWORDS.size +
        SecurityLogic.FILE_SUSPICIOUS_KEYWORDS.size

    with(sharedTransitionScope) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(colors.background)
    ) {
        ScanningRadarBackgroundCanvas(
            progress = progress,
            animatedProgress = animatedSweep,
            modifier = Modifier.fillMaxSize()
        )

        Column(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp, vertical = 22.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(18.dp)
        ) {
            Column(
                modifier = Modifier.fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = if (progress.isLoading) {
                        stringResource(R.string.scan_title_loading)
                    } else {
                        stringResource(R.string.scan_title_finishing)
                    },
                    style = MaterialTheme.typography.headlineMedium,
                    color = colors.textPrimary,
                    modifier = Modifier.sharedBounds(
                        sharedContentState = rememberSharedContentState(key = "scan_headline"),
                        animatedVisibilityScope = animatedVisibilityScope,
                        boundsTransform = sharedBoundsTransform,
                        resizeMode = SharedTransitionScope.ResizeMode.RemeasureToBounds,
                        zIndexInOverlay = 1f
                    )
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = stringResource(R.string.scan_engine_rules, signatureRulesCount),
                    style = MaterialTheme.typography.bodyMedium,
                    color = colors.accent
                )
                if (progress.isLoading) {
                    Spacer(modifier = Modifier.height(10.dp))
                    LinearProgressIndicator(
                        modifier = Modifier
                            .fillMaxWidth(0.65f)
                            .height(4.dp)
                            .clip(RoundedCornerShape(4.dp)),
                        color = colors.primary,
                        trackColor = colors.border.copy(alpha = 0.25f)
                    )
                }
            }

            // Anillo de progreso con degradado azul conectado mediante Shared Element a Resultados
            Box(
                modifier = Modifier
                    .size(188.dp)
                    .sharedElement(
                        state = rememberSharedContentState(key = "scan_hero_emblem"),
                        animatedVisibilityScope = animatedVisibilityScope,
                        boundsTransform = sharedBoundsTransform,
                        zIndexInOverlay = 1f
                    ),
                contentAlignment = Alignment.Center
            ) {
                Canvas(modifier = Modifier.fillMaxSize()) {
                    val strokeWidth = 13.dp.toPx()
                    drawArc(
                        color = colors.border.copy(alpha = if (colors.isHighContrast) 0.20f else 0.45f),
                        startAngle = 0f,
                        sweepAngle = 360f,
                        useCenter = false,
                        style = Stroke(width = strokeWidth, cap = StrokeCap.Round)
                    )

                    val ringColors = if (progress.alertsFound > 0) {
                        listOf(colors.primary, colors.accent, colors.statusAmber, colors.primary)
                    } else {
                        listOf(colors.primary, colors.accent, colors.primary)
                    }

                    drawArc(
                        brush = Brush.sweepGradient(colors = ringColors),
                        startAngle = -90f,
                        sweepAngle = 360f * animatedSweep,
                        useCenter = false,
                        style = Stroke(width = strokeWidth, cap = StrokeCap.Round)
                    )
                }

                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = "$animatedPercent%",
                        style = MaterialTheme.typography.headlineLarge.copy(
                            fontSize = 40.sp,
                            fontWeight = FontWeight.Bold
                        ),
                        color = colors.textPrimary
                    )
                    Text(
                        text = if (progress.isLoading) {
                            stringResource(R.string.scan_ring_scanning)
                        } else {
                            stringResource(R.string.scan_ring_completed)
                        },
                        style = MaterialTheme.typography.bodyMedium,
                        color = colors.textSecondary
                    )
                }
            }

        // Contadores en tiempo real conectados a la tarjeta resumen de Resultados
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .sharedBounds(
                    sharedContentState = rememberSharedContentState(key = "scan_summary_card"),
                    animatedVisibilityScope = animatedVisibilityScope,
                    boundsTransform = sharedBoundsTransform,
                    resizeMode = SharedTransitionScope.ResizeMode.RemeasureToBounds
                ),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            LiveMetricTile(
                label = stringResource(R.string.scan_metric_apps),
                value = progress.appsChecked.toString(),
                valueColor = colors.textPrimary,
                modifier = Modifier.weight(1f)
            )
            LiveMetricTile(
                label = stringResource(R.string.scan_metric_files),
                value = progress.filesChecked.toString(),
                valueColor = colors.textPrimary,
                modifier = Modifier.weight(1f)
            )
            LiveMetricTile(
                label = stringResource(R.string.scan_metric_alerts),
                value = animatedAlerts.toString(),
                valueColor = when {
                    progress.liveFindings.any { it.severity == FindingSeverity.ALERT } -> colors.statusRed
                    animatedAlerts > 0 -> colors.statusAmber
                    else -> colors.statusGreen
                },
                modifier = Modifier.weight(1f)
            )
        }

        // Etapas que aparecen una por una con check animado
        Column(
            modifier = Modifier.fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            val stages = listOf(
                ScanStage.FREE_FIRE,
                ScanStage.APPS,
                ScanStage.FILES
            )

            stages.forEachIndexed { index, stage ->
                val isCompleted = stage in progress.completedStages
                val isCurrent = stage == progress.currentStage && progress.isLoading
                val isVisible = isCompleted || isCurrent || index <= progress.currentStage.ordinal

                AnimatedVisibility(
                    visible = isVisible,
                    enter = fadeIn(tween(320)) + slideInVertically(tween(320)) { it / 2 }
                ) {
                    val rowModifier = if (stage == ScanStage.FREE_FIRE) {
                        Modifier.sharedBounds(
                            sharedContentState = rememberSharedContentState(key = "free_fire_card"),
                            animatedVisibilityScope = animatedVisibilityScope,
                            boundsTransform = sharedBoundsTransform,
                            resizeMode = SharedTransitionScope.ResizeMode.RemeasureToBounds
                        )
                    } else {
                        Modifier
                    }
                    StageRow(
                        title = stringResource(stage.titleRes),
                        isCompleted = isCompleted,
                        isCurrent = isCurrent,
                        modifier = rowModifier
                    )
                }
            }
        }

        // Estado actual en vivo y alertas detectadas en tiempo real
        Column(
            modifier = Modifier.fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text(
                text = progress.statusDetail,
                style = MaterialTheme.typography.bodyMedium,
                color = colors.textSecondary,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )

            if (!progress.currentTargetName.isNullOrBlank()) {
                Text(
                    text = stringResource(R.string.scan_analyzing_target, progress.currentTargetName),
                    style = MaterialTheme.typography.bodyMedium.copy(fontSize = 12.sp),
                    color = colors.accent,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }

            AnimatedVisibility(
                visible = progress.liveFindings.isNotEmpty(),
                enter = fadeIn(tween(300)) + slideInVertically(tween(300)) { it / 3 }
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = stringResource(R.string.scan_live_alerts_header),
                        style = MaterialTheme.typography.labelLarge,
                        color = colors.statusAmber
                    )
                    progress.liveFindings.forEach { finding ->
                        LiveFindingPreviewRow(finding = finding)
                    }
                }
            }
        }
    }
    }
    }
}

@Composable
private fun ScanningRadarBackgroundCanvas(
    progress: ScanProgress,
    animatedProgress: Float,
    modifier: Modifier = Modifier
) {
    val colors = LocalFFColors.current
    var radarPhase by remember { mutableFloatStateOf(0f) }
    val currentSweep by rememberUpdatedState(animatedProgress)
    val currentIsLoading by rememberUpdatedState(progress.isLoading)

    LaunchedEffect(Unit) {
        var lastFrameNanos = withFrameNanos { it }
        while (true) {
            withFrameNanos { frameNanos ->
                val dtSeconds = ((frameNanos - lastFrameNanos).coerceAtLeast(0L)) / 1_000_000_000f
                lastFrameNanos = frameNanos
                val speed = if (currentIsLoading) {
                    0.38f + 0.52f * currentSweep
                } else {
                    0.16f
                }
                radarPhase = (radarPhase + dtSeconds * speed) % 1f
            }
        }
    }

    val hasCriticalAlert = progress.liveFindings.any { it.severity == FindingSeverity.ALERT }
    val hasWarning = progress.liveFindings.isNotEmpty()
    val pulseTint = when {
        hasCriticalAlert -> colors.statusRed
        hasWarning -> colors.statusAmber
        !progress.isLoading && animatedProgress >= 0.99f -> colors.statusGreen
        else -> colors.accent
    }
    val ringTint = if (hasCriticalAlert || hasWarning) pulseTint else colors.primary

    Canvas(modifier = modifier) {
        val center = Offset(
            x = size.width / 2f,
            y = minOf(size.height * 0.30f, 224.dp.toPx())
        )
        val innerCoreRadius = 86.dp.toPx()
        val maxRadius = hypot(
            size.width * 0.55f,
            (size.height - center.y).coerceAtLeast(center.y)
        )

        // Resplandor radial central sincronizado con el avance del escaneo
        if (!colors.isHighContrast) {
            val coreGlowAlpha = 0.14f + 0.14f * animatedProgress
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(
                        ringTint.copy(alpha = coreGlowAlpha),
                        pulseTint.copy(alpha = coreGlowAlpha * 0.45f),
                        Color.Transparent
                    ),
                    center = center,
                    radius = maxRadius * 0.72f
                ),
                radius = maxRadius * 0.72f,
                center = center
            )
        }

        // Retícula fija de referencia (anillos que se iluminan según el progreso)
        val dashEffect = PathEffect.dashPathEffect(floatArrayOf(10f, 12f), 0f)
        val guideThresholds = listOf(0.28f, 0.52f, 0.76f, 1.0f)
        guideThresholds.forEach { threshold ->
            val guideRadius = innerCoreRadius + (maxRadius - innerCoreRadius) * threshold
            val reached = animatedProgress >= threshold - 0.12f
            val baseAlpha = when {
                colors.isHighContrast && reached -> 0.16f
                colors.isHighContrast -> 0.08f
                reached -> 0.18f
                else -> 0.08f
            }
            drawCircle(
                color = (if (reached) pulseTint else colors.border).copy(alpha = baseAlpha),
                radius = guideRadius,
                center = center,
                style = Stroke(
                    width = if (reached) 1.3.dp.toPx() else 1.dp.toPx(),
                    pathEffect = dashEffect
                )
            )
        }

        // Haz de barrido del radar sincronizado con el progreso y la fase continua
        val sweepRotation = (animatedProgress * 360f + radarPhase * 360f) % 360f
        val sweepRadius = innerCoreRadius + (maxRadius - innerCoreRadius) * (0.45f + 0.55f * animatedProgress)
        rotate(degrees = sweepRotation, pivot = center) {
            drawArc(
                brush = Brush.sweepGradient(
                    0.0f to Color.Transparent,
                    0.72f to Color.Transparent,
                    0.92f to pulseTint.copy(alpha = if (colors.isHighContrast) 0.09f else 0.15f),
                    1.0f to pulseTint.copy(alpha = if (colors.isHighContrast) 0.18f else 0.28f),
                    center = center
                ),
                startAngle = 0f,
                sweepAngle = 360f,
                useCenter = true,
                topLeft = Offset(center.x - sweepRadius, center.y - sweepRadius),
                size = Size(sweepRadius * 2f, sweepRadius * 2f)
            )
        }

        // Ondas pulsantes concéntricas cuyo alcance crece con el progreso del análisis
        val dynamicReach = innerCoreRadius + (maxRadius - innerCoreRadius) * (0.38f + 0.62f * animatedProgress)
        val waveCount = 3
        for (index in 0 until waveCount) {
            val waveProgress = (radarPhase + index.toFloat() / waveCount) % 1f
            val waveRadius = innerCoreRadius + (dynamicReach - innerCoreRadius) * waveProgress
            val fadeOut = (1f - waveProgress).coerceIn(0f, 1f)
            val strokeAlpha = fadeOut * fadeOut * (if (colors.isHighContrast) 0.30f else 0.38f)

            drawCircle(
                color = ringTint.copy(alpha = strokeAlpha),
                radius = waveRadius,
                center = center,
                style = Stroke(width = (2.6f - 1.2f * waveProgress).dp.toPx())
            )
        }

        // Onda maestra acoplada directamente al porcentaje y etapa actual (0..100%)
        val stageLocalWave = if (progress.isLoading) {
            (animatedProgress * 3f) % 1f
        } else {
            1f
        }
        val progressWaveRadius = innerCoreRadius + (maxRadius - innerCoreRadius) * stageLocalWave
        val progressWaveAlpha = if (progress.isLoading) {
            (1f - stageLocalWave * 0.65f) * (if (colors.isHighContrast) 0.26f else 0.34f)
        } else {
            0.14f
        }
        drawCircle(
            color = pulseTint.copy(alpha = progressWaveAlpha),
            radius = progressWaveRadius,
            center = center,
            style = Stroke(width = 2.dp.toPx())
        )
    }
}

@Composable
private fun LiveMetricTile(
    label: String,
    value: String,
    valueColor: Color,
    modifier: Modifier = Modifier
) {
    val colors = LocalFFColors.current
    Surface(
        modifier = modifier,
        color = colors.surface,
        shape = RoundedCornerShape(14.dp),
        border = BorderStroke(colors.borderWidth, colors.border)
    ) {
        Column(
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 12.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(2.dp)
        ) {
            Text(
                text = value,
                style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
                color = valueColor
            )
            Text(
                text = label,
                style = MaterialTheme.typography.bodyMedium.copy(fontSize = 12.sp),
                color = colors.textSecondary
            )
        }
    }
}

@Composable
private fun LiveFindingPreviewRow(finding: ScanFinding) {
    val colors = LocalFFColors.current
    val accent = if (finding.severity == FindingSeverity.ALERT) colors.statusRed else colors.statusAmber
    val icon = if (finding.severity == FindingSeverity.ALERT) {
        Icons.Outlined.ErrorOutline
    } else {
        Icons.Outlined.WarningAmber
    }

    Surface(
        modifier = Modifier.fillMaxWidth(),
        color = colors.surface,
        shape = RoundedCornerShape(12.dp),
        border = BorderStroke(colors.borderWidth, accent.copy(alpha = 0.7f))
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            AppPackageIcon(
                packageName = finding.packageName,
                fallbackIcon = icon,
                fallbackTint = accent,
                size = 30.dp
            )
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = finding.title,
                    style = MaterialTheme.typography.labelLarge.copy(fontSize = 13.sp),
                    color = colors.textPrimary,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    text = finding.reason,
                    style = MaterialTheme.typography.bodyMedium.copy(fontSize = 12.sp),
                    color = colors.textSecondary,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
    }
}

@Composable
private fun StageRow(
    title: String,
    isCompleted: Boolean,
    isCurrent: Boolean,
    modifier: Modifier = Modifier
) {
    val colors = LocalFFColors.current
    Surface(
        modifier = modifier.fillMaxWidth(),
        color = colors.surface,
        shape = RoundedCornerShape(14.dp),
        border = BorderStroke(
            width = colors.borderWidth,
            color = when {
                isCompleted -> colors.statusGreen
                isCurrent -> colors.primary
                else -> colors.border
            }
        )
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Box(
                modifier = Modifier.size(22.dp),
                contentAlignment = Alignment.Center
            ) {
                if (isCompleted) {
                    AnimatedCheckmark(checkColor = colors.statusGreen)
                } else if (isCurrent) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(18.dp),
                        color = colors.accent,
                        strokeWidth = 2.5.dp
                    )
                }
            }
            Text(
                text = title,
                style = MaterialTheme.typography.bodyLarge.copy(fontSize = 14.sp),
                color = if (isCompleted || isCurrent) colors.textPrimary else colors.textSecondary
            )
        }
    }
}

@Composable
private fun AnimatedCheckmark(checkColor: Color) {
    val progress by animateFloatAsState(
        targetValue = 1f,
        animationSpec = tween(durationMillis = 380, easing = FastOutSlowInEasing),
        label = "checkDraw"
    )
    Canvas(modifier = Modifier.size(22.dp)) {
        val w = size.width
        val h = size.height
        drawCircle(color = checkColor.copy(alpha = 0.18f))

        val p1 = Offset(w * 0.25f, h * 0.52f)
        val p2 = Offset(w * 0.44f, h * 0.70f)
        val p3 = Offset(w * 0.76f, h * 0.34f)

        val path = Path().apply {
            moveTo(p1.x, p1.y)
            val firstHalf = (progress * 2f).coerceIn(0f, 1f)
            lineTo(
                p1.x + (p2.x - p1.x) * firstHalf,
                p1.y + (p2.y - p1.y) * firstHalf
            )
            if (progress > 0.5f) {
                val secondHalf = ((progress - 0.5f) * 2f).coerceIn(0f, 1f)
                lineTo(
                    p2.x + (p3.x - p2.x) * secondHalf,
                    p2.y + (p3.y - p2.y) * secondHalf
                )
            }
        }
        drawPath(
            path = path,
            color = checkColor,
            style = Stroke(
                width = 2.6.dp.toPx(),
                cap = StrokeCap.Round,
                join = StrokeJoin.Round
            )
        )
    }
}
