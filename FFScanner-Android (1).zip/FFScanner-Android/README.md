# FF Scanner (Android - Kotlin + Jetpack Compose + Material 3)

Aplicación Android de verificación local diseñada para revisar el teléfono en busca de señales comunes de modificación o trampas asociadas a Free Fire (`com.dts.freefireth`) y Free Fire MAX (`com.dts.freefiremax`).

## Requisitos para compilar
- **Android Studio** Jellyfish (2023.3.1) o superior
- **JDK 17**
- **Android SDK 35** (`compileSdk = 35`, `targetSdk = 35`, `minSdk = 26` / Android 8.0+)

## Pasos para generar el APK

### Opción 1: Desde Android Studio (Recomendado)
1. Abre **Android Studio** y selecciona **Open**.
2. Elige la carpeta `android-project` (donde está `settings.gradle.kts`).
3. Espera a que termine **Gradle Sync** automáticamente.
4. En el menú superior ve a:
   `Build > Build Bundle(s) / APK(s) > Build APK(s)`
5. Cuando finalice, haz clic en **locate** en la notificación o abre:
   `app/build/outputs/apk/debug/app-debug.apk`
6. Pasa ese archivo `.apk` a tu teléfono Android e instálalo activando *"Orígenes desconocidos"*.

### Opción 2: Para generar un APK firmado (Release)
1. Ve a `Build > Generate Signed Bundle / APK...`
2. Selecciona **APK** y presiona **Next**.
3. Crea un Keystore nuevo (`Create new...`) o elige uno existente.
4. Selecciona el build variant **release** y presiona **Create**.
5. El APK firmado quedará en `app/build/outputs/apk/release/app-release.apk`.

## Permisos y privacidad
- Declara `INTERNET`, `ACCESS_NETWORK_STATE` y `ACCESS_WIFI_STATE` para detectar el estado de red (Wi-Fi / datos móviles) sin realizar envíos ocultos ni cargas automáticas.
- Declara `QUERY_ALL_PACKAGES` y `MANAGE_EXTERNAL_STORAGE` (con respaldo `READ_EXTERNAL_STORAGE` en Android 8–12L) exclusivamente bajo consentimiento expreso.
- Todo el análisis de paquetes y almacenamiento es local, visible y transparente; nunca desinstala aplicaciones ni elimina archivos.
