@echo off
echo === Compilando FF Scanner APK (Android 8 - 16) ===
where gradle >nul 2>nul
if %errorlevel%==0 (
  call gradle assembleDebug assembleRelease --no-daemon
) else if exist gradlew.bat (
  call gradlew.bat assembleDebug assembleRelease --no-daemon
) else (
  echo Error: No se encontro gradle en PATH. Abre esta carpeta desde Android Studio.
  pause
  exit /b 1
)

echo.
echo APKs generados:
echo   - app\build\outputs\apk\debug\app-debug.apk
echo   - app\build\outputs\apk\release\app-release.apk
pause
